package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.ui.navigation.KalarAppScaffold
import com.example.ui.theme.KalarTheme
import com.example.viewmodel.KalarViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KalarViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val isKurdish = uiState.language == AppLanguage.KURDISH
            val darkTheme = when (uiState.themeMode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
            }
            val layoutDirection = if (isKurdish) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                KalarTheme(
                    darkTheme = darkTheme,
                    isKurdish = isKurdish
                ) {
                    KalarAppScaffold(
                        uiState = uiState,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}
