package com.example.data

import com.example.model.KalarCalendarDates
import java.util.Calendar
import java.util.TimeZone

/**
 * Pure, allocation-light dual calendar converter for Kalar (Asia/Baghdad timezone),
 * producing exact Gregorian and Kurdish Solar Hijri (Kurdish Era = Solar Hijri + 1321)
 * day, month, and year values.
 */
object KalarCalendarHelper {

    private val kalarTimeZone: TimeZone = TimeZone.getTimeZone("Asia/Baghdad")

    private val kurdishMonthsKu = arrayOf(
        "خاکەلێوە",
        "گوڵان",
        "جۆزەردان",
        "پووشپەڕ",
        "گەلاوێژ",
        "خەرمانان",
        "ڕەزبەر",
        "گەڵاڕێزان",
        "سەرماوەرز",
        "بەفرانبار",
        "ڕێبەندان",
        "ڕەشەمێ"
    )

    private val kurdishMonthsEn = arrayOf(
        "Xakelêwe",
        "Gulan",
        "Cozerdan",
        "Pûşpeř",
        "Gelawêj",
        "Xermanan",
        "Řezber",
        "Gelařêzan",
        "Sermawerz",
        "Befranbar",
        "Řêbendan",
        "Řeşemê"
    )

    private val gregorianMonthsKu = arrayOf(
        "کانوونی دووەم",
        "شوبات",
        "ئازار",
        "نیسان",
        "ئایار",
        "حوزەیران",
        "تەممووز",
        "ئاب",
        "ئەیلوول",
        "تشرینی یەکەم",
        "تشرینی دووەم",
        "کانوونی یەکەم"
    )

    private val gregorianMonthsEn = arrayOf(
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec"
    )

    private val weekdaysKu = arrayOf(
        "یەکشەممە",
        "دووشەممە",
        "سێشەممە",
        "چوارشەممە",
        "پێنجشەممە",
        "هەینی",
        "شەممە"
    )

    private val weekdaysEn = arrayOf(
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
    )

    fun currentKalarDates(nowEpochMs: Long = System.currentTimeMillis()): KalarCalendarDates {
        val cal = Calendar.getInstance(kalarTimeZone).apply {
            timeInMillis = nowEpochMs
        }
        val gYear = cal.get(Calendar.YEAR)
        val gMonth = cal.get(Calendar.MONTH) + 1
        val gDay = cal.get(Calendar.DAY_OF_MONTH)
        val dayOfWeekIndex = (cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
        return fromGregorian(
            gregorianYear = gYear,
            gregorianMonth = gMonth,
            gregorianDay = gDay,
            dayOfWeekIndex = dayOfWeekIndex
        )
    }

    fun fromGregorian(
        gregorianYear: Int,
        gregorianMonth: Int,
        gregorianDay: Int,
        dayOfWeekIndex: Int? = null
    ): KalarCalendarDates {
        val resolvedDow = dayOfWeekIndex ?: run {
            val cal = Calendar.getInstance(kalarTimeZone).apply {
                set(gregorianYear, gregorianMonth - 1, gregorianDay, 12, 0, 0)
            }
            (cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
        }

        val (jalaliYear, jalaliMonth, jalaliDay) = gregorianToJalali(
            gy = gregorianYear,
            gm = gregorianMonth,
            gd = gregorianDay
        )
        val kurdishYear = jalaliYear + 1321

        return KalarCalendarDates(
            weekdayKu = weekdaysKu[resolvedDow],
            weekdayEn = weekdaysEn[resolvedDow],
            kurdishDay = jalaliDay,
            kurdishMonthKu = kurdishMonthsKu[(jalaliMonth - 1).coerceIn(0, 11)],
            kurdishMonthEn = kurdishMonthsEn[(jalaliMonth - 1).coerceIn(0, 11)],
            kurdishYear = kurdishYear,
            gregorianDay = gregorianDay,
            gregorianMonthKu = gregorianMonthsKu[(gregorianMonth - 1).coerceIn(0, 11)],
            gregorianMonthEn = gregorianMonthsEn[(gregorianMonth - 1).coerceIn(0, 11)],
            gregorianYear = gregorianYear
        )
    }

    /**
     * Exact Gregorian to Solar Hijri conversion algorithm (astronomical cycle).
     */
    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gDaysInMonth[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return Triple(jy, jm, jd)
    }
}
