package com.example.data

import com.example.R
import com.example.model.CategorizedFacebookPage
import com.example.model.CityFactSection
import com.example.model.CityLandmark
import com.example.model.CityService
import com.example.model.CityStat
import com.example.model.EmergencyContact
import com.example.model.HealthFacility
import com.example.model.HealthFacilityType
import com.example.model.LocalizedText
import com.example.model.NeighborhoodItem
import com.example.model.NewsArticle
import com.example.model.NewsCategory
import com.example.model.NewsSourcePage
import com.example.model.OfficialLinkItem
import com.example.model.OfficialLinkType
import com.example.model.OfficialPageCategory
import com.example.model.OfficialPageIconType
import com.example.model.PageBrandIdentity
import com.example.model.PageEmblemStyle
import com.example.model.ServiceCategory
import com.example.model.ServiceIconType

object KalarRepository {

    const val AMADA_PACKAGE_ID = "com.amadaapp.client"
    const val AMADA_PLAY_STORE_URL =
        "https://play.google.com/store/apps/details?id=com.amadaapp.client"

    private val allowedFacebookHosts = setOf(
        "www.facebook.com",
        "facebook.com",
        "m.facebook.com"
    )

    fun isOfficialFacebookUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (!trimmed.startsWith("https://")) return false
        val afterScheme = trimmed.removePrefix("https://")
        val host = afterScheme.substringBefore('/').substringBefore('?').lowercase()
        return host in allowedFacebookHosts
    }

    fun isAllowedExternalUrl(url: String): Boolean {
        val trimmed = url.trim()
        return isOfficialFacebookUrl(trimmed) || trimmed == AMADA_PLAY_STORE_URL
    }

    val cityStats: List<CityStat> = listOf(
        CityStat(
            id = "region",
            label = LocalizedText(ku = "ئیدارە", en = "Administration"),
            value = LocalizedText(ku = "گەرمیان", en = "Garmian"),
            detail = LocalizedText(ku = "ناوەندی ئیدارەی سەربەخۆی گەرمیان", en = "Capital of Garmian Admin.")
        ),
        CityStat(
            id = "population",
            label = LocalizedText(ku = "دانیشتوان", en = "Population"),
            value = LocalizedText(ku = "~٢٦٠ هەزار", en = "~260,000"),
            detail = LocalizedText(ku = "شار و دەوروبەری", en = "Urban & district center")
        ),
        CityStat(
            id = "elevation",
            label = LocalizedText(ku = "بەرزی", en = "Elevation"),
            value = LocalizedText(ku = "١٩٦ مەتر", en = "196 m"),
            detail = LocalizedText(ku = "لە ئاستی دەریاوە", en = "Above sea level")
        ),
        CityStat(
            id = "river",
            label = LocalizedText(ku = "ڕووبار", en = "River"),
            value = LocalizedText(ku = "سیروان", en = "Sirwan"),
            detail = LocalizedText(ku = "دەروازەی سروشت و ژیان", en = "Lifeline of the valley")
        )
    )

    val landmarks: List<CityLandmark> = listOf(
        CityLandmark(
            id = "shirwana",
            name = LocalizedText(ku = "قەڵای شێروانە", en = "Sherwana Castle"),
            category = LocalizedText(ku = "شوێنەوار و مێژوو", en = "Heritage Monument"),
            summary = LocalizedText(
                ku = "هێمای مێژوویی کەلار و مووزەخانەی گەرمیان لەسەر تەپۆڵکەی دێرین.",
                en = "Historic 1866 brick citadel & Garmian Museum overlooking Kalar."
            ),
            fullDescription = LocalizedText(
                ku = "قەڵای شێروانە لە ساڵی ١٨٦٦ لەلایەن محەمەد پاشای جافەوە لە شاری کەلار بنیاد نراوە و یەکێکە لە دیارترین هێما مێژووییەکانی ناوچەی گەرمیان. ئێستا مۆزەخانەی کەلەپووری گەرمیانی تێدایە.",
                en = "Built around 1866 by Mohamed Pasha Jaff, Sherwana Castle stands as the iconic cultural landmark of Kalar and the Garmian region, housing the Garmian Heritage Museum atop an ancient mound."
            ),
            location = LocalizedText(ku = "گەڕەکی شێروانە، کەلار", en = "Sherwana District, Kalar"),
            visitingHours = LocalizedText(ku = "٨:٣٠ بەیانی – ٥:٠٠ ئێوارە", en = "8:30 AM – 5:00 PM"),
            highlights = listOf(
                LocalizedText(ku = "مۆزەخانەی شوێنەوار", en = "Archaeological Museum"),
                LocalizedText(ku = "دیمەنی پانۆرامای شار", en = "Panoramic City View"),
                LocalizedText(ku = "تەلارسازی خشتی ڕەسەن", en = "Traditional Brick Architecture")
            ),
            imageRes = R.drawable.img_kalar_shirwana
        ),
        CityLandmark(
            id = "cityscape",
            name = LocalizedText(ku = "دیمەنی شاری کەلار", en = "Kalar City Panorama"),
            category = LocalizedText(ku = "شاری کەلار", en = "City Overview"),
            summary = LocalizedText(
                ku = "دیمەنی ڕاستەقینەی شاری کەلار لەسەر تەپۆڵکەی قەڵای شێروانەوە.",
                en = "Real-world panoramic view across Kalar from Sherwana Castle."
            ),
            fullDescription = LocalizedText(
                ku = "دیمەنێکی فراوانی شاری کەلار لە بەرزایی قەڵای شێروانەوە کە گەڕەکە دێرین و نوێیەکانی ناوەندی گەرمیان پیشان دەدات.",
                en = "Sweeping real-world vista overlooking Kalar's neighborhoods, tree-lined avenues, and surrounding Garmian plains."
            ),
            location = LocalizedText(ku = "ناوەندی شاری کەلار", en = "Central Kalar"),
            visitingHours = LocalizedText(ku = "کراوەیە ٢٤ کاتژمێر", en = "Open 24 Hours"),
            highlights = listOf(
                LocalizedText(ku = "دیمەنی پانۆراما", en = "City Skyline"),
                LocalizedText(ku = "شەقامی سەرەکی", en = "Main Boulevards")
            ),
            imageRes = R.drawable.img_kalar_cityscape
        ),
        CityLandmark(
            id = "sirwan",
            name = LocalizedText(ku = "ڕووباری سیروان", en = "Sirwan River"),
            category = LocalizedText(ku = "سروشت و گەشتیاری", en = "Nature & River"),
            summary = LocalizedText(
                ku = "کەناری ئاو و سەوزایی گەرمیان بۆ گەشت و پشووی خێزانی.",
                en = "Scenic Sirwan River valley nourishing Kalar and eastern Garmian."
            ),
            fullDescription = LocalizedText(
                ku = "ڕووباری سیروان بە قەراغی شاری کەلاردا تێدەپەڕێت و ڕەنگێکی سەوز و زیندوو بە دۆڵی گەرمیان دەبەخشێت.",
                en = "Flowing beside Kalar along the eastern valley of Garmian, the Sirwan River nourishes fertile orchards and provides refreshing riverside walks."
            ),
            location = LocalizedText(ku = "کەناری ڕۆژهەڵاتی کەلار", en = "Eastern Edge of Kalar"),
            visitingHours = LocalizedText(ku = "کراوەیە ٢٤ کاتژمێر", en = "Open 24 Hours"),
            highlights = listOf(
                LocalizedText(ku = "سەوزایی کەناراو", en = "Riverside Groves"),
                LocalizedText(ku = "ڕێڕەوی پیاسە", en = "Walking Trails")
            ),
            imageRes = R.drawable.img_sirwan_river
        ),
        CityLandmark(
            id = "kalar_center",
            name = LocalizedText(ku = "ناوەند و شەقامەکانی کەلار", en = "Kalar Urban Center"),
            category = LocalizedText(ku = "بازاڕ و ژیانی شار", en = "Urban Life"),
            summary = LocalizedText(
                ku = "وێنەی ڕاستەقینەی ناوەندی بازرگانی و گەڕەکەکانی شاری کەلار.",
                en = "Authentic view of Kalar's bustling commercial district and streets."
            ),
            fullDescription = LocalizedText(
                ku = "ناوەندی شاری کەلار جێگەی جووڵەی ڕۆژانەی هاووڵاتیانی گەرمیان و بازاڕە سەرەکییەکانە.",
                en = "Kalar's central streets unite local markets, neighborhood shops, and everyday Garmian hospitality."
            ),
            location = LocalizedText(ku = "ناوەندی شاری کەلار", en = "Downtown Kalar"),
            visitingHours = LocalizedText(ku = "٨:٠٠ بەیانی – ١٠:٠٠ شەو", en = "8:00 AM – 10:00 PM"),
            highlights = listOf(
                LocalizedText(ku = "بازاڕی ناوەندی", en = "Central Bazaar"),
                LocalizedText(ku = "شەقامە سەرەکییەکان", en = "Main Streets")
            ),
            imageRes = R.drawable.img_garmian_bazaar
        )
    )

    // --- All 4 Provided Hospitals & Medical Centers in Kalar ---
    val healthFacilities: List<HealthFacility> = listOf(
        HealthFacility(
            id = "xzmat_medical_city",
            type = HealthFacilityType.HOSPITAL,
            name = LocalizedText(ku = "شاری پزیشکیی خزمەت", en = "Xzmat Medical City"),
            subtitle = LocalizedText(ku = "شاری پزیشکیی خزمەت لە کەلار", en = "Xzmat Medical City • Kalar"),
            description = LocalizedText(
                ku = "شاری پزیشکیی خزمەت یەکێکە لە ناوەندە پزیشکییە دیارەکانی شاری کەلار بۆ چارەسەری نەخۆشییەکان، تاقیگە و ڕاوێژکاری پزیشکی.",
                en = "Xzmat Medical City in Kalar offering specialist clinics, diagnostic services, and medical consultations. Tap below to open the official Facebook page."
            ),
            address = LocalizedText(ku = "کەلار، گەرمیان", en = "Kalar, Garmian"),
            hours = LocalizedText(ku = "کراوەیە ٢٤ کاتژمێر", en = "Open 24 Hours"),
            phone = "+9647701400122",
            facebookUrl = "https://www.facebook.com/XzmatMedicalCity?mibextid=ZbWKwL",
            is24Hours = true,
            specialties = listOf(
                LocalizedText(ku = "ڕاوێژکاری پزیشکی", en = "Specialist Clinics"),
                LocalizedText(ku = "تاقیگە و تیشک", en = "Labs & Radiology")
            )
        ),
        HealthFacility(
            id = "kalar_medical_center_2",
            type = HealthFacilityType.HOSPITAL,
            name = LocalizedText(ku = "نەخۆشخانەی کەلار • 14wvax", en = "Kalar Hospital • 14wvax"),
            subtitle = LocalizedText(ku = "پەیجی فەرمی فەیسبووک (share/14wvaxSEWjH)", en = "Official Facebook Page (14wvaxSEWjH)"),
            description = LocalizedText(
                ku = "بەستەری ڕاستەوخۆی پەیجی فەرمی نەخۆشخانە لە کەلار؛ کلیک بکە بۆ کردنەوەی پەیجە ڕاستەقینەکە لە فەیسبووک بەبێ هیچ ڕیکلام و پەنجەرەیەکی زیادە.",
                en = "Direct official Facebook page for this Kalar hospital. Opens directly in Facebook cleanly without third-party websites or popups."
            ),
            address = LocalizedText(ku = "کەلار، گەرمیان", en = "Kalar, Garmian"),
            hours = LocalizedText(ku = "کراوەیە ٢٤ کاتژمێر", en = "Open 24 Hours"),
            phone = "+9647701400230",
            facebookUrl = "https://www.facebook.com/share/14wvaxSEWjH/",
            is24Hours = true,
            specialties = listOf(
                LocalizedText(ku = "چاودێری پزیشکی", en = "Medical Care"),
                LocalizedText(ku = "کلینیکی پسپۆڕی", en = "Outpatient Care")
            )
        ),
        HealthFacility(
            id = "kalar_medical_center_3",
            type = HealthFacilityType.CLINIC_PHARMACY,
            name = LocalizedText(ku = "ناوەندی پزیشکی کەلار • 16TKS5", en = "Kalar Medical • 16TKS5"),
            subtitle = LocalizedText(ku = "پەیجی فەرمی فەیسبووک (share/16TKS5XAwZ9)", en = "Official Facebook Page (16TKS5XAwZ9)"),
            description = LocalizedText(
                ku = "بەستەری ڕاستەوخۆی پەیجی فەرمی ناوەندی پزیشکی لە کەلار؛ کلیک بکە بۆ کردنەوەی پەیجە ڕاستەقینەکە لە فەیسبووک.",
                en = "Direct official Facebook page for this Kalar healthcare center. Opens cleanly inside Facebook."
            ),
            address = LocalizedText(ku = "کەلار، گەرمیان", en = "Kalar, Garmian"),
            hours = LocalizedText(ku = "٨:٣٠ بەیانی – ١١:٠٠ شەو", en = "8:30 AM – 11:00 PM"),
            phone = "+9647701400245",
            facebookUrl = "https://www.facebook.com/share/16TKS5XAwZ9/",
            is24Hours = false,
            specialties = listOf(
                LocalizedText(ku = "پشکنینی پزیشکی", en = "Diagnostics"),
                LocalizedText(ku = "دەرمانخانە", en = "Pharmacy")
            )
        ),
        HealthFacility(
            id = "kalar_public_hospital",
            type = HealthFacilityType.EMERGENCY,
            name = LocalizedText(ku = "نەخۆشخانەی حکومی کەلار", en = "Kalar Government Hospital"),
            subtitle = LocalizedText(ku = "نەخۆشخانەی حکومی و فریاکەوتنی کەلار", en = "Public Hospital & 24/7 Emergency"),
            description = LocalizedText(
                ku = "نەخۆشخانەی حکومی شاری کەلار بۆ فریاکەوتن، نەشتەرگەری و خزمەتگوزارییە گشتییە تەندروستییەکانی هاووڵاتیان.",
                en = "Kalar's public government hospital providing 24/7 emergency care, inpatient wards, and general medical treatment."
            ),
            address = LocalizedText(ku = "کەلار، گەرمیان", en = "Kalar, Garmian"),
            hours = LocalizedText(ku = "٢٤ کاتژمێر • هەموو ڕۆژێک", en = "24/7 • Daily"),
            phone = "122",
            facebookUrl = "https://www.facebook.com/share/1EzW2JiPiQ/",
            is24Hours = true,
            specialties = listOf(
                LocalizedText(ku = "فریاکەوتنی ١٢٢", en = "122 Emergency"),
                LocalizedText(ku = "نەشتەرگەری گشتی", en = "General Surgery"),
                LocalizedText(ku = "تاقیگە و تیشک", en = "Labs & Imaging")
            )
        )
    )

    // --- All 7 Provided Official Directorate, Weather, Condolences & Community Links ---
    val officialLinks: List<OfficialLinkItem> = listOf(
        OfficialLinkItem(
            id = "traffic_directorate",
            type = OfficialLinkType.TRAFFIC,
            title = LocalizedText(ku = "بەڕێوبەرایەتی هاتووچۆ کەلار", en = "Kalar Traffic Directorate"),
            subtitle = LocalizedText(ku = "پەیجی بەڕێوبەرایەتی هاتووچۆ کەلار", en = "Official Kalar Traffic Page"),
            description = LocalizedText(
                ku = "ڕێنماییەکانی هاتووچۆ، مۆڵەتی شۆفێری، تۆماری ئۆتۆمبێل و ئاگاداری ڕێگاکانی کەلار.",
                en = "Official Kalar Traffic Directorate announcements, driver licensing notices, road safety alerts, and 188 hotline."
            ),
            badge = LocalizedText(ku = "هاتووچۆ • ١٨٨", en = "Traffic • 188"),
            phone = "188",
            url = "https://www.facebook.com/share/1UFWApB3cR/"
        ),
        OfficialLinkItem(
            id = "education_directorate",
            type = OfficialLinkType.EDUCATION,
            title = LocalizedText(ku = "بەڕێوبەرایەتی پەروەردەی کەلار", en = "Kalar Education Directorate"),
            subtitle = LocalizedText(ku = "پەیجی فەرمی پەروەردەی کەلار", en = "Official Education Portal"),
            description = LocalizedText(
                ku = "هەواڵ و ئاگادارییەکانی قوتابخانەکان، خشتەی تاقیکردنەوەکان و ڕێنمایی پەروەردە لە کەلار.",
                en = "Official school notices, exam timetables, academic announcements, and student updates for Kalar."
            ),
            badge = LocalizedText(ku = "پەروەردە", en = "Education"),
            phone = null,
            url = "https://www.facebook.com/Parwarda.Kalar?mibextid=ZbWKwL"
        ),
        OfficialLinkItem(
            id = "garmian_weather",
            type = OfficialLinkType.WEATHER,
            title = LocalizedText(ku = "گەش و هەوای گەرمیان", en = "Garmian Weather"),
            subtitle = LocalizedText(ku = "پێشبینی ڕۆژانەی کەشوهەوا لە گەرمیان", en = "Live Garmian Weather Page"),
            description = LocalizedText(
                ku = "پێشبینی پلەی گەرمی، بارانبارین، خێرایی با و ئاگاداری کەشوهەوای کەلار و گەرمیان.",
                en = "Follow daily forecasts, temperature updates, rain alerts, and regional weather bulletins for Kalar & Garmian."
            ),
            badge = LocalizedText(ku = "کەشوهەوا", en = "Weather"),
            phone = null,
            url = "https://www.facebook.com/KhshWHhwayGhRmyan?mibextid=ZbWKwL"
        ),
        OfficialLinkItem(
            id = "condolences_pages",
            type = OfficialLinkType.CONDOLENCES,
            title = LocalizedText(ku = "تەعزێکانی کەلار", en = "Kalar Condolences"),
            subtitle = LocalizedText(ku = "هەواڵی پرسە و سەرەخۆشی لە کەلار", en = "Kalar Bereavement Notices"),
            description = LocalizedText(
                ku = "ئاگاداری پرسە و تەعزێکانی ناو شاری کەلار، شوێنی مزگەوتەکان و کاتی سەرەخۆشی.",
                en = "Community page sharing Kalar condolence announcements, mosque locations, and memorial hours."
            ),
            badge = LocalizedText(ku = "تەعزێکان", en = "Condolences"),
            phone = null,
            url = "https://www.facebook.com/share/1EszZTGE1L/"
        ),
        OfficialLinkItem(
            id = "official_page_1zdc",
            type = OfficialLinkType.OFFICIAL_PAGE,
            title = LocalizedText(ku = "پەیجی کەلار • 1ZDCa4", en = "Kalar Page • 1ZDCa4"),
            subtitle = LocalizedText(ku = "فەیسبووک (share/1ZDCa41jZ2)", en = "Facebook (share/1ZDCa41jZ2)"),
            description = LocalizedText(
                ku = "بەستەری ڕاستەوخۆی پەیجی فەرمی فەیسبووک (1ZDCa41jZ2)؛ بۆ بینینی ناوەڕۆکە ڕەسەنەکە کلیک بکە.",
                en = "Direct official Facebook page (share/1ZDCa41jZ2). Opens cleanly inside Facebook without external ads."
            ),
            badge = LocalizedText(ku = "فەیسبووک", en = "Facebook"),
            phone = null,
            url = "https://www.facebook.com/share/1ZDCa41jZ2/"
        ),
        OfficialLinkItem(
            id = "official_page_1szf",
            type = OfficialLinkType.OFFICIAL_PAGE,
            title = LocalizedText(ku = "پەیجی کەلار • 1SzfaP", en = "Kalar Page • 1SzfaP"),
            subtitle = LocalizedText(ku = "فەیسبووک (share/1SzfaPzoXB)", en = "Facebook (share/1SzfaPzoXB)"),
            description = LocalizedText(
                ku = "بەستەری ڕاستەوخۆی پەیجی فەرمی فەیسبووک (1SzfaPzoXB)؛ بۆ بینینی ناوەڕۆکە ڕەسەنەکە کلیک بکە.",
                en = "Direct official Facebook page (share/1SzfaPzoXB). Opens cleanly inside Facebook without external ads."
            ),
            badge = LocalizedText(ku = "فەیسبووک", en = "Facebook"),
            phone = null,
            url = "https://www.facebook.com/share/1SzfaPzoXB/"
        ),
        OfficialLinkItem(
            id = "official_page_1c4r",
            type = OfficialLinkType.OFFICIAL_PAGE,
            title = LocalizedText(ku = "پەیجی کەلار • 1C4RPd", en = "Kalar Page • 1C4RPd"),
            subtitle = LocalizedText(ku = "فەیسبووک (share/1C4RPds29y)", en = "Facebook (share/1C4RPds29y)"),
            description = LocalizedText(
                ku = "بەستەری ڕاستەوخۆی پەیجی فەرمی فەیسبووک (1C4RPds29y)؛ بۆ بینینی ناوەڕۆکە ڕەسەنەکە کلیک بکە.",
                en = "Direct official Facebook page (share/1C4RPds29y). Opens cleanly inside Facebook without external ads."
            ),
            badge = LocalizedText(ku = "فەیسبووک", en = "Facebook"),
            phone = null,
            url = "https://www.facebook.com/share/1C4RPds29y/"
        )
    )

    // --- Unique Per-Page Brand Profile Identities (20 distinct colors, monograms & crests) ---
    private val defaultBrand = PageBrandIdentity(
        id = "default",
        monogram = "KL",
        primaryColorHex = 0xFF8C3B22,
        secondaryColorHex = 0xFFD97706,
        emblemStyle = PageEmblemStyle.RADIAL_CREST,
        iconType = OfficialPageIconType.OFFICIAL
    )

    val pageBrands: Map<String, PageBrandIdentity> = mapOf(
        "xzmat_medical_city" to PageBrandIdentity(
            id = "xzmat_medical_city",
            monogram = "خز",
            primaryColorHex = 0xFF0E7C66,
            secondaryColorHex = 0xFF14B8A6,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.HOSPITAL
        ),
        "kalar_medical_center_2" to PageBrandIdentity(
            id = "kalar_medical_center_2",
            monogram = "4W",
            primaryColorHex = 0xFFC62828,
            secondaryColorHex = 0xFFEF5350,
            emblemStyle = PageEmblemStyle.DOUBLE_RING,
            iconType = OfficialPageIconType.HOSPITAL
        ),
        "kalar_medical_center_3" to PageBrandIdentity(
            id = "kalar_medical_center_3",
            monogram = "TK",
            primaryColorHex = 0xFF0277BD,
            secondaryColorHex = 0xFF29B6F6,
            emblemStyle = PageEmblemStyle.DIAGONAL_BADGE,
            iconType = OfficialPageIconType.CLINIC
        ),
        "kalar_public_hospital" to PageBrandIdentity(
            id = "kalar_public_hospital",
            monogram = "١٢٢",
            primaryColorHex = 0xFFB71C1C,
            secondaryColorHex = 0xFFD84315,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.EMERGENCY
        ),
        "traffic_directorate" to PageBrandIdentity(
            id = "traffic_directorate",
            monogram = "١٨٨",
            primaryColorHex = 0xFF1A237E,
            secondaryColorHex = 0xFF3949AB,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.TRAFFIC
        ),
        "education_directorate" to PageBrandIdentity(
            id = "education_directorate",
            monogram = "پە",
            primaryColorHex = 0xFF4527A0,
            secondaryColorHex = 0xFF7E57C2,
            emblemStyle = PageEmblemStyle.DOUBLE_RING,
            iconType = OfficialPageIconType.EDUCATION
        ),
        "garmian_weather" to PageBrandIdentity(
            id = "garmian_weather",
            monogram = "گە",
            primaryColorHex = 0xFFEF6C00,
            secondaryColorHex = 0xFFFFA726,
            emblemStyle = PageEmblemStyle.RADIAL_CREST,
            iconType = OfficialPageIconType.WEATHER
        ),
        "condolences_pages" to PageBrandIdentity(
            id = "condolences_pages",
            monogram = "تە",
            primaryColorHex = 0xFF37474F,
            secondaryColorHex = 0xFF607D8B,
            emblemStyle = PageEmblemStyle.DOUBLE_RING,
            iconType = OfficialPageIconType.CONDOLENCES
        ),
        "official_page_1zdc" to PageBrandIdentity(
            id = "official_page_1zdc",
            monogram = "ZD",
            primaryColorHex = 0xFFBF360C,
            secondaryColorHex = 0xFFE64A19,
            emblemStyle = PageEmblemStyle.DIAGONAL_BADGE,
            iconType = OfficialPageIconType.OFFICIAL
        ),
        "official_page_1szf" to PageBrandIdentity(
            id = "official_page_1szf",
            monogram = "SZ",
            primaryColorHex = 0xFF2E7D32,
            secondaryColorHex = 0xFF66BB6A,
            emblemStyle = PageEmblemStyle.RADIAL_CREST,
            iconType = OfficialPageIconType.OFFICIAL
        ),
        "official_page_1c4r" to PageBrandIdentity(
            id = "official_page_1c4r",
            monogram = "CR",
            primaryColorHex = 0xFF6A1B9A,
            secondaryColorHex = 0xFFAB47BC,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.OFFICIAL
        ),
        "kalar_news_1ewa" to PageBrandIdentity(
            id = "kalar_news_1ewa",
            monogram = "با",
            primaryColorHex = 0xFF880E4F,
            secondaryColorHex = 0xFFD81B60,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_news_16r2" to PageBrandIdentity(
            id = "kalar_news_16r2",
            monogram = "R2",
            primaryColorHex = 0xFF0D47A1,
            secondaryColorHex = 0xFF1E88E5,
            emblemStyle = PageEmblemStyle.DIAGONAL_BADGE,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_news_1fzc" to PageBrandIdentity(
            id = "kalar_news_1fzc",
            monogram = "FZ",
            primaryColorHex = 0xFFE65100,
            secondaryColorHex = 0xFFFB8C00,
            emblemStyle = PageEmblemStyle.RADIAL_CREST,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_news_1de7" to PageBrandIdentity(
            id = "kalar_news_1de7",
            monogram = "D7",
            primaryColorHex = 0xFF1B5E20,
            secondaryColorHex = 0xFF43A047,
            emblemStyle = PageEmblemStyle.DOUBLE_RING,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_ktv" to PageBrandIdentity(
            id = "kalar_ktv",
            monogram = "KTV",
            primaryColorHex = 0xFFD32F2F,
            secondaryColorHex = 0xFF1565C0,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.NEWS_TV
        ),
        "kalar_news_1ahg" to PageBrandIdentity(
            id = "kalar_news_1ahg",
            monogram = "AH",
            primaryColorHex = 0xFF004D40,
            secondaryColorHex = 0xFF00897B,
            emblemStyle = PageEmblemStyle.DIAGONAL_BADGE,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_news_18gg" to PageBrandIdentity(
            id = "kalar_news_18gg",
            monogram = "8G",
            primaryColorHex = 0xFF311B92,
            secondaryColorHex = 0xFF5E35B1,
            emblemStyle = PageEmblemStyle.RADIAL_CREST,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "ayinde_media" to PageBrandIdentity(
            id = "ayinde_media",
            monogram = "ئا",
            primaryColorHex = 0xFF01579B,
            secondaryColorHex = 0xFF00ACC1,
            emblemStyle = PageEmblemStyle.DOUBLE_RING,
            iconType = OfficialPageIconType.NEWS_MEDIA
        ),
        "kalar_news_1frp" to PageBrandIdentity(
            id = "kalar_news_1frp",
            monogram = "FR",
            primaryColorHex = 0xFF4E342E,
            secondaryColorHex = 0xFF8D6E63,
            emblemStyle = PageEmblemStyle.SHIELD_CREST,
            iconType = OfficialPageIconType.NEWS_MEDIA
        )
    )

    fun brandForId(id: String): PageBrandIdentity = pageBrands[id] ?: defaultBrand

    // --- All 9 Provided Local Kalar News Pages ---
    val newsSources: List<NewsSourcePage> = listOf(
        NewsSourcePage(
            id = "kalar_news_1ewa",
            name = LocalizedText(ku = "میدیای باجه لان", en = "Bajelan Media"),
            tagline = LocalizedText(ku = "پەیجی هەواڵ • share/1Ewad4WPfr", en = "News Page • share/1Ewad4WPfr"),
            url = "https://www.facebook.com/share/1Ewad4WPfr/",
            brand = brandForId("kalar_news_1ewa")
        ),
        NewsSourcePage(
            id = "kalar_news_16r2",
            name = LocalizedText(ku = "هەواڵی کەلار • 16R2CX", en = "Kalar News • 16R2CX"),
            tagline = LocalizedText(ku = "فەیسبووک (share/16R2CXi5rU5)", en = "Facebook (share/16R2CXi5rU5)"),
            url = "https://www.facebook.com/share/16R2CXi5rU5/",
            brand = brandForId("kalar_news_16r2")
        ),
        NewsSourcePage(
            id = "kalar_news_1fzc",
            name = LocalizedText(ku = "هەواڵی کەلار • 1FZcYw", en = "Kalar News • 1FZcYw"),
            tagline = LocalizedText(ku = "فەیسبووک (share/1FZcYwS3Ay)", en = "Facebook (share/1FZcYwS3Ay)"),
            url = "https://www.facebook.com/share/1FZcYwS3Ay/",
            brand = brandForId("kalar_news_1fzc")
        ),
        NewsSourcePage(
            id = "kalar_news_1de7",
            name = LocalizedText(ku = "هەواڵی کەلار • 1De7G1", en = "Kalar News • 1De7G1"),
            tagline = LocalizedText(ku = "فەیسبووک (share/1De7G1chpd)", en = "Facebook (share/1De7G1chpd)"),
            url = "https://www.facebook.com/share/1De7G1chpd/",
            brand = brandForId("kalar_news_1de7")
        ),
        NewsSourcePage(
            id = "kalar_ktv",
            name = LocalizedText(ku = "کەلار KTV", en = "Kalar KTV"),
            tagline = LocalizedText(ku = "میدیا و هەواڵی کەلار KTV", en = "Kalar KTV Media Channel"),
            url = "https://www.facebook.com/kalarktv?mibextid=ZbWKwL",
            brand = brandForId("kalar_ktv")
        ),
        NewsSourcePage(
            id = "kalar_news_1ahg",
            name = LocalizedText(ku = "هەواڵی کەلار • 1AHGtt", en = "Kalar News • 1AHGtt"),
            tagline = LocalizedText(ku = "فەیسبووک (share/1AHGttcmbM)", en = "Facebook (share/1AHGttcmbM)"),
            url = "https://www.facebook.com/share/1AHGttcmbM/",
            brand = brandForId("kalar_news_1ahg")
        ),
        NewsSourcePage(
            id = "kalar_news_18gg",
            name = LocalizedText(ku = "هەواڵی کەلار • 18ggtw", en = "Kalar News • 18ggtw"),
            tagline = LocalizedText(ku = "فەیسبووک (share/18ggtwBofn)", en = "Facebook (share/18ggtwBofn)"),
            url = "https://www.facebook.com/share/18ggtwBofn/",
            brand = brandForId("kalar_news_18gg")
        ),
        NewsSourcePage(
            id = "ayinde_media",
            name = LocalizedText(ku = "ئایندە میدیا", en = "Ayinde Media"),
            tagline = LocalizedText(ku = "پەیجی فەرمی ئایندە میدیا", en = "Ayinde Media News"),
            url = "https://www.facebook.com/Ayindemedia?mibextid=ZbWKwL",
            brand = brandForId("ayinde_media")
        ),
        NewsSourcePage(
            id = "kalar_news_1frp",
            name = LocalizedText(ku = "هەواڵی کەلار • 1FRpyz", en = "Kalar News • 1FRpyz"),
            tagline = LocalizedText(ku = "فەیسبووک (share/1FRpyzYLeZ)", en = "Facebook (share/1FRpyzYLeZ)"),
            url = "https://www.facebook.com/share/1FRpyzYLeZ/",
            brand = brandForId("kalar_news_1frp")
        )
    )

    // --- Aggregated News Feed Timeline (unique page logo per post, no landmark photos) ---
    val newsArticles: List<NewsArticle> = listOf(
        NewsArticle(
            id = "news_kalar_ktv",
            sourceId = "kalar_ktv",
            category = NewsCategory.CULTURE_SPORTS,
            sourceName = LocalizedText(ku = "کەلار KTV", en = "Kalar KTV"),
            publishedAgo = LocalizedText(ku = "١ کاتژمێر لەمەوبەر", en = "1 hour ago"),
            title = LocalizedText(
                ku = "دوایین پێشهات و هەواڵە خێراکانی کەلار و گەرمیان لە کەلار KTV",
                en = "Latest Kalar & Garmian Coverage from Kalar KTV"
            ),
            summary = LocalizedText(
                ku = "ڕاپۆرتی ڕۆژانە، چالاکییە کۆمەڵایەتییەکان و هەواڵی شاری کەلار لە کەلار KTV.",
                en = "Daily community coverage, cultural features, and Garmian updates directly on Kalar KTV."
            ),
            body = LocalizedText(
                ku = "پەیجی فەرمی کەلار KTV بەردەوام ڕاپۆرت و هەواڵە ناوخۆییەکانی شاری کەلار و گەرمیان بڵاودەکاتەوە. بۆ بینینی دوایین پۆست و ڤیدیۆ ڕاستەوخۆکان کلیک لە فەیسبووک بکە.",
                en = "Follow Kalar KTV's official Facebook page for daily civic dispatches and community reports across Garmian. Opens directly on Facebook with zero ads or popups."
            ),
            url = "https://www.facebook.com/kalarktv?mibextid=ZbWKwL",
            brand = brandForId("kalar_ktv")
        ),
        NewsArticle(
            id = "news_bajelan_media",
            sourceId = "kalar_news_1ewa",
            category = NewsCategory.LOCAL,
            sourceName = LocalizedText(ku = "میدیای باجه لان", en = "Bajelan Media"),
            publishedAgo = LocalizedText(ku = "٢ کاتژمێر لەمەوبەر", en = "2 hours ago"),
            title = LocalizedText(
                ku = "ڕووماڵی ڕاستەوخۆی هەواڵ و ڕووداوە ناوخۆییەکان لە میدیای باجه لان",
                en = "Local Kalar Headlines & Updates from Bajelan Media"
            ),
            summary = LocalizedText(
                ku = "دەنگوباسی خێرای ناو شاری کەلار، ئاگاداری فەرمانگەکان و ڕاپۆرتی ڕۆژانە لە میدیای باجه لان.",
                en = "Fast-moving Kalar civic updates, commercial news, and neighborhood notices from Bajelan Media."
            ),
            body = LocalizedText(
                ku = "بۆ بینینی هەموو پۆستە نوێیەکانی میدیای باجه لان لە تایملاینی فەیسبووک، بە سەلامەتی و بەبێ هیچ پەنجەرەیەکی زیادە پەیجە فەرمییەکە بکەرەوە.",
                en = "View the latest posts published by Bajelan Media directly inside Facebook with zero popups or external redirectors."
            ),
            url = "https://www.facebook.com/share/1Ewad4WPfr/",
            brand = brandForId("kalar_news_1ewa")
        ),
        NewsArticle(
            id = "news_ayinde_media",
            sourceId = "ayinde_media",
            category = NewsCategory.MUNICIPAL,
            sourceName = LocalizedText(ku = "ئایندە میدیا", en = "Ayinde Media"),
            publishedAgo = LocalizedText(ku = "٢ کاتژمێر لەمەوبەر", en = "2 hours ago"),
            title = LocalizedText(
                ku = "هەواڵە خزمەتگوزاری و ڕاپۆرتە ڕۆژنامەوانییەکانی ئایندە میدیا لە گەرمیان",
                en = "Civic Services & Regional Reporting from Ayinde Media"
            ),
            summary = LocalizedText(
                ku = "چاودێریکردنی پڕۆژە خزمەتگوزارییەکان، دۆخی ئاوی سیروان و ڕێگاوبانەکانی سنووری کەلار.",
                en = "Ongoing updates covering municipal projects, infrastructure, and Garmian civic developments."
            ),
            body = LocalizedText(
                ku = "ئایندە میدیا ڕووماڵی هەواڵە گشتییەکان، پڕۆژەکانی شارەوانی و ڕووداوە گرنگەکانی گەرمیان دەکات. بۆ بینینی نوێترین بڵاوکراوەکان ڕاستەوخۆ پەیجە فەرمییەکە بکەرەوە.",
                en = "Ayinde Media shares verified local reporting across Kalar and Garmian. Tap below to open the latest posts cleanly on Facebook."
            ),
            url = "https://www.facebook.com/Ayindemedia?mibextid=ZbWKwL",
            brand = brandForId("ayinde_media")
        ),
        NewsArticle(
            id = "news_kalar_16r2",
            sourceId = "kalar_news_16r2",
            category = NewsCategory.LOCAL,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 16R2CX", en = "Kalar News • 16R2CX"),
            publishedAgo = LocalizedText(ku = "٤ کاتژمێر لەمەوبەر", en = "4 hours ago"),
            title = LocalizedText(
                ku = "هەواڵ و ڕووداوە گشتییەکانی کەلار و دەوروبەری گەرمیان",
                en = "Kalar District & Garmian Community Dispatch"
            ),
            summary = LocalizedText(
                ku = "پۆستە نوێیەکانی کۆمەڵگا، ئاگاداری هاووڵاتیان و چالاکییە ناوخۆییەکانی شاری کەلار.",
                en = "Public notices, local highlights, and daily dispatches serving Kalar and surrounding towns."
            ),
            body = LocalizedText(
                ku = "ئەم بەشەی تایملاین دوایین زانیارییەکانی ئەم سەرچاوە هەواڵییەت بۆ کۆدەکاتەوە؛ بە یەک کلیک پۆستە ڕاستەوخۆکان لە فەیسبووک دەبینیت.",
                en = "Browse directly to the live Facebook feed of this local Kalar source for full announcements and community posts."
            ),
            url = "https://www.facebook.com/share/16R2CXi5rU5/",
            brand = brandForId("kalar_news_16r2")
        ),
        NewsArticle(
            id = "news_kalar_1fzc",
            sourceId = "kalar_news_1fzc",
            category = NewsCategory.MUNICIPAL,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 1FZcYw", en = "Kalar News • 1FZcYw"),
            publishedAgo = LocalizedText(ku = "٥ کاتژمێر لەمەوبەر", en = "5 hours ago"),
            title = LocalizedText(
                ku = "ئاگادارییە خزمەتگوزاری و ڕێنماییەکانی هاووڵاتیان لە کەلار",
                en = "Public Service Notices & City Bulletins in Kalar"
            ),
            summary = LocalizedText(
                ku = "ئاگاداری کاتی کارەبا، ئاو، ڕێگاوبان و خزمەتگوزارییە گشتییەکان بۆ دانیشتوانی کەلار.",
                en = "Useful local announcements regarding public utilities, city roads, and citizen advisories."
            ),
            body = LocalizedText(
                ku = "سەردانی پەیجە فەرمییەکە بکە لە فەیسبووک بۆ خوێندنەوەی نوێترین ئاگادارییە بڵاوکراوەکانی ئەمڕۆ.",
                en = "Open the official Facebook page directly to read today's complete announcements in a clean, ad-free flow."
            ),
            url = "https://www.facebook.com/share/1FZcYwS3Ay/",
            brand = brandForId("kalar_news_1fzc")
        ),
        NewsArticle(
            id = "news_kalar_1de7",
            sourceId = "kalar_news_1de7",
            category = NewsCategory.CULTURE_SPORTS,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 1De7G1", en = "Kalar News • 1De7G1"),
            publishedAgo = LocalizedText(ku = "٧ کاتژمێر لەمەوبەر", en = "7 hours ago"),
            title = LocalizedText(
                ku = "چالاکی خوێندکاران، وەرزش و بۆنە کولتوورییەکانی کەلار",
                en = "Youth, Education & Cultural Highlights Across Kalar"
            ),
            summary = LocalizedText(
                ku = "هەواڵی چالاکی گەنجان، زانکۆ، قوتابخانەکان و بۆنە کۆمەڵایەتییە خێزانییەکان.",
                en = "Family-friendly coverage of local youth programs, university events, and cultural gatherings."
            ),
            body = LocalizedText(
                ku = "بۆ بینینی وێنە و ڤیدیۆی چالاکییە نوێیەکان ڕاستەوخۆ پەیجە فەرمییەکە لە فەیسبووک بکەرەوە.",
                en = "Tap below to open the official Facebook timeline for photos and updates on recent community events."
            ),
            url = "https://www.facebook.com/share/1De7G1chpd/",
            brand = brandForId("kalar_news_1de7")
        ),
        NewsArticle(
            id = "news_kalar_1ahg",
            sourceId = "kalar_news_1ahg",
            category = NewsCategory.LOCAL,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 1AHGtt", en = "Kalar News • 1AHGtt"),
            publishedAgo = LocalizedText(ku = "٩ کاتژمێر لەمەوبەر", en = "9 hours ago"),
            title = LocalizedText(
                ku = "پوختەی هەواڵە خێراکانی گەرمیان و ناوەندی کەلار",
                en = "Rapid Garmian & Kalar Local News Roundup"
            ),
            summary = LocalizedText(
                ku = "گەیاندنی دوایین هەواڵ و ڕووداوە گرنگەکانی شاری کەلار بۆ خێزانەکان بە شێوەیەکی پاک و سەلامەت.",
                en = "Clean, family-safe summaries connecting you straight to recent posts on the official page."
            ),
            body = LocalizedText(
                ku = "هەموو پۆستەکانی ئەم سەرچاوەیە ڕاستەوخۆ لە پەیجە فەرمییەکەی فەیسبووک دەکرێنەوە بەبێ تێپەڕبوون بە هیچ سایتێکی دەرەکی.",
                en = "Every article link opens strictly inside the official Facebook app or clean browser view with zero external ad pages."
            ),
            url = "https://www.facebook.com/share/1AHGttcmbM/",
            brand = brandForId("kalar_news_1ahg")
        ),
        NewsArticle(
            id = "news_kalar_18gg",
            sourceId = "kalar_news_18gg",
            category = NewsCategory.MUNICIPAL,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 18ggtw", en = "Kalar News • 18ggtw"),
            publishedAgo = LocalizedText(ku = "دوێنێ", en = "Yesterday"),
            title = LocalizedText(
                ku = "پەرەپێدانی ژینگە، سەوزایی و شەقامەکانی کەناری سیروان",
                en = "Sirwan Valley Roads, Parks & Environmental Updates"
            ),
            summary = LocalizedText(
                ku = "زانیاری دەربارەی پاراستنی ژینگەی گەرمیان، باخچە گشتییەکان و جووڵەی هاتووچۆ.",
                en = "Updates on Kalar green spaces, riverside parks, and neighborhood road improvements."
            ),
            body = LocalizedText(
                ku = "پەیجی فەرمی بکەرەوە بۆ بینینی نوێترین پۆستەکانی پەیوەست بە پاکوخاوێنی و سەوزایی کەلار.",
                en = "Open the live Facebook page directly to see recent neighborhood improvement posts."
            ),
            url = "https://www.facebook.com/share/18ggtwBofn/",
            brand = brandForId("kalar_news_18gg")
        ),
        NewsArticle(
            id = "news_kalar_1frp",
            sourceId = "kalar_news_1frp",
            category = NewsCategory.LOCAL,
            sourceName = LocalizedText(ku = "هەواڵی کەلار • 1FRpyz", en = "Kalar News • 1FRpyz"),
            publishedAgo = LocalizedText(ku = "دوێنێ", en = "Yesterday"),
            title = LocalizedText(
                ku = "ڕاگەیاندراو و چالاکییە گشتییەکانی شاری کەلار",
                en = "Kalar Daily Announcements & Public Bulletins"
            ),
            summary = LocalizedText(
                ku = "دوایین بڵاوکراوەکانی کۆمەڵگا و ئاگادارییە پێویستەکان لە پەیجی فەرمییەوە.",
                en = "Community notices and essential updates aggregated directly from the official Facebook page."
            ),
            body = LocalizedText(
                ku = "بۆ بینینی ناوەڕۆکی تەواوی پۆستە تازەکان ڕاستەوخۆ پەیجی فەرمی لە فەیسبووک بکەرەوە.",
                en = "Tap to view full recent posts directly on Facebook."
            ),
            url = "https://www.facebook.com/share/1FRpyzYLeZ/",
            brand = brandForId("kalar_news_1frp")
        )
    )

    // --- Categorized Official Facebook Pages (All 20 provided URLs with unique brands) ---
    val categorizedPages: List<CategorizedFacebookPage> by lazy {
        val healthPages = healthFacilities.map { facility ->
            CategorizedFacebookPage(
                id = "cat_${facility.id}",
                category = OfficialPageCategory.HEALTH_MEDICAL,
                name = facility.name,
                subtitle = facility.subtitle,
                badge = if (facility.is24Hours) {
                    LocalizedText(ku = "تەندروستی • ٢٤/٧", en = "Health • 24/7")
                } else {
                    LocalizedText(ku = "تەندروستی", en = "Medical")
                },
                url = facility.facebookUrl,
                phone = facility.phone,
                brand = brandForId(facility.id)
            )
        }

        val directorateAndCommunityPages = officialLinks.map { link ->
            val category = when (link.type) {
                OfficialLinkType.TRAFFIC,
                OfficialLinkType.EDUCATION,
                OfficialLinkType.WEATHER -> OfficialPageCategory.DIRECTORATES_WEATHER
                OfficialLinkType.CONDOLENCES,
                OfficialLinkType.OFFICIAL_PAGE -> OfficialPageCategory.COMMUNITY_OFFICIAL
            }
            CategorizedFacebookPage(
                id = "cat_${link.id}",
                category = category,
                name = link.title,
                subtitle = link.subtitle,
                badge = link.badge,
                url = link.url,
                phone = link.phone,
                brand = brandForId(link.id)
            )
        }

        val newsPages = newsSources.map { source ->
            CategorizedFacebookPage(
                id = "cat_${source.id}",
                category = OfficialPageCategory.LOCAL_NEWS,
                name = source.name,
                subtitle = source.tagline,
                badge = LocalizedText(ku = "هەواڵ", en = "News"),
                url = source.url,
                phone = null,
                brand = source.brand
            )
        }

        healthPages + directorateAndCommunityPages + newsPages
    }

    // --- O(1) Pre-indexed In-Memory Caches for High-Scale Smooth Rendering ---
    val pagesByCategory: Map<OfficialPageCategory, List<CategorizedFacebookPage>> by lazy {
        val grouped = categorizedPages.groupBy { it.category }
        buildMap {
            put(OfficialPageCategory.ALL, categorizedPages)
            OfficialPageCategory.entries
                .filter { it != OfficialPageCategory.ALL }
                .forEach { cat -> put(cat, grouped[cat].orEmpty()) }
        }
    }

    val pageCountsByCategory: Map<OfficialPageCategory, Int> by lazy {
        pagesByCategory.mapValues { it.value.size }
    }

    val newsBySourceId: Map<String, List<NewsArticle>> by lazy {
        newsArticles.groupBy { it.sourceId }
    }

    val newsByCategory: Map<NewsCategory, List<NewsArticle>> by lazy {
        val grouped = newsArticles.groupBy { it.category }
        buildMap {
            put(NewsCategory.ALL, newsArticles)
            NewsCategory.entries
                .filter { it != NewsCategory.ALL }
                .forEach { cat -> put(cat, grouped[cat].orEmpty()) }
        }
    }

    val services: List<CityService> = listOf(
        CityService(
            id = "municipality",
            category = ServiceCategory.MUNICIPAL,
            title = LocalizedText(ku = "شارەوانی کەلار", en = "Kalar Municipality"),
            subtitle = LocalizedText(ku = "مۆڵەتی بینا و پاکوخاوێنی", en = "Permits, zoning & urban care"),
            description = LocalizedText(
                ku = "سەرۆکایەتی شارەوانی کەلار بەرپرسە لە پێدانی مۆڵەتی بیناسازی، پڕۆژە خزمەتگوزارییەکان، باخچەکان و ڕێکخستنی بازاڕ و کۆڵانەکان.",
                en = "Handles building permits, urban planning, public sanitation, neighborhood parks, and municipal business licensing across Kalar."
            ),
            officeName = LocalizedText(ku = "سەرۆکایەتی شارەوانی کەلار", en = "Kalar Municipality Presidency"),
            address = LocalizedText(ku = "شەقامی سەرەکی شارەوانی، کەلار", en = "Main Municipality St, Kalar"),
            hours = LocalizedText(ku = "یەکشەممە – پێنجشەممە • ٨:٣٠ – ٢:٠٠", en = "Sun – Thu • 8:30 AM – 2:00 PM"),
            phone = "+9647701400100",
            isOpenNow = true,
            iconType = ServiceIconType.MUNICIPALITY,
            requiredDocs = listOf(
                LocalizedText(ku = "کارتی نیشتمانی یان ناسنامە", en = "National ID Card"),
                LocalizedText(ku = "تاپۆ یان گرێبەستی موڵک", en = "Property Deed / Title"),
                LocalizedText(ku = "نەخشەی ئەندازیاری پەسەندکراو", en = "Approved Architectural Plan")
            )
        ),
        CityService(
            id = "hospital",
            category = ServiceCategory.HEALTH,
            title = LocalizedText(ku = "نەخۆشخانەی حکومی کەلار", en = "Government Hospital"),
            subtitle = LocalizedText(ku = "فریاکەوتن و چارەسەری ٢٤ کاتژمێری", en = "24/7 emergency & specialist care"),
            description = LocalizedText(
                ku = "ناوەندی سەرەکی تەندروستی لە کەلار بۆ فریاکەوتنی خێرا، نەشتەرگەری، تاقیگە و ڕاوێژکاری پزیشکی بۆ هەموو دانیشتوانی گەرمیان.",
                en = "Kalar's primary public medical center offering 24/7 emergency care, diagnostics, outpatient clinics, and specialist surgical units."
            ),
            officeName = LocalizedText(ku = "نەخۆشخانەی حکومی کەلار", en = "Kalar Government Hospital"),
            address = LocalizedText(ku = "کەلار، گەرمیان", en = "Kalar, Garmian"),
            hours = LocalizedText(ku = "کراوەیە ٢٤ کاتژمێر • هەموو ڕۆژێک", en = "Open 24 Hours • Daily"),
            phone = "122",
            isOpenNow = true,
            iconType = ServiceIconType.HOSPITAL,
            requiredDocs = listOf(
                LocalizedText(ku = "ناسنامە بۆ تۆمارکردنی دۆسیە", en = "ID for Patient Registration"),
                LocalizedText(ku = "فایلی پزیشکی پێشوو (ئەگەر هەبێت)", en = "Previous Medical Records (if any)")
            )
        ),
        CityService(
            id = "utilities",
            category = ServiceCategory.UTILITIES,
            title = LocalizedText(ku = "کارەبا و ئاوی کەلار", en = "Water & Electricity"),
            subtitle = LocalizedText(ku = "پێوەری زیرەک، چاککردنەوە و پسوڵە", en = "Billing, meters & outage support"),
            description = LocalizedText(
                ku = "خزمەتگوزاری دابینکردنی ئاوی خواردنەوە، چاککردنەوەی هێڵەکانی کارەبا، دانانی پێوەری زیرەک و چارەسەرکردنی کێشەی هاوبەشان.",
                en = "Manages municipal drinking water supply, electrical grid maintenance, smart meter connections, and utility billing inquiries."
            ),
            officeName = LocalizedText(ku = "بەڕێوەبەرایەتی کارەبا و ئاوی گەرمیان", en = "Garmian Utilities Directorate"),
            address = LocalizedText(ku = "شەقامی سیروان، کەلار", en = "Sirwan Avenue, Kalar"),
            hours = LocalizedText(ku = "یەکشەممە – پێنجشەممە • ٨:٣٠ – ٢:٠٠", en = "Sun – Thu • 8:30 AM – 2:00 PM"),
            phone = "+9647701400155",
            isOpenNow = true,
            iconType = ServiceIconType.WATER_POWER,
            requiredDocs = listOf(
                LocalizedText(ku = "ژمارەی هاوبەشی کارەبا یان ئاو", en = "Utility Account / Meter Number"),
                LocalizedText(ku = "کارتی نیشتمانی و کارتی زانیاری", en = "National ID & Residence Card")
            )
        ),
        CityService(
            id = "civil_records",
            category = ServiceCategory.MUNICIPAL,
            title = LocalizedText(ku = "کارتی نیشتمانی و ڕەگەزنامە", en = "Civil Status & ID"),
            subtitle = LocalizedText(ku = "دەرهێنان و نوێکردنەوەی بەڵگەنامە", en = "National ID & family records"),
            description = LocalizedText(
                ku = "پێشکەشکردنی خزمەتگوزاری دەرکردن و نوێکردنەوەی کارتی نیشتمانی، تۆمارکردنی لەدایکبوون و هاوسەرگیری و بەڵگەنامە فەرمییەکان.",
                en = "Official civil affairs center for issuing and renewing National IDs, registering births and marriages, and residence records."
            ),
            officeName = LocalizedText(ku = "فەرمانگەی کارتی نیشتمانی کەلار", en = "Kalar National ID Office"),
            address = LocalizedText(ku = "گەڕەکی بەردەسوور، کەلار", en = "Bardasoor District, Kalar"),
            hours = LocalizedText(ku = "یەکشەممە – پێنجشەممە • ٨:٠٠ – ٢:٠٠", en = "Sun – Thu • 8:00 AM – 2:00 PM"),
            phone = "+9647701400180",
            isOpenNow = true,
            iconType = ServiceIconType.CIVIL_RECORDS,
            requiredDocs = listOf(
                LocalizedText(ku = "نۆرەی ئەلیکترۆنی پێشوەختە", en = "Confirmed Online Appointment"),
                LocalizedText(ku = "کارتی زانیاری و بەڵگەنامەی کۆن", en = "Residence Card & Existing Records")
            )
        ),
        CityService(
            id = "transport",
            category = ServiceCategory.TRANSPORT,
            title = LocalizedText(ku = "گواستنەوە و هاتوچۆ", en = "Transit & Traffic"),
            subtitle = LocalizedText(ku = "گەراجی گشتی و مۆڵەتی شۆفێری", en = "City terminal & driver licensing"),
            description = LocalizedText(
                ku = "ڕێکخستنی هێڵەکانی گواستنەوەی نێوان کەلار – سلێمانی – کەرکوک – خانەقین و خزمەتگوزارییەکانی مۆڵەتی شۆفێری و تۆماری ئۆتۆمبێل.",
                en = "Intercity bus terminal connecting Kalar to Sulaymaniyah, Erbil, Kirkuk, and Khanaqin, plus driver licensing and vehicle registration."
            ),
            officeName = LocalizedText(ku = "بەڕێوەبەرایەتی هاتوچۆ و گەراجی کەلار", en = "Kalar Traffic & Transit Hub"),
            address = LocalizedText(ku = "دەروازەی باکووری کەلار", en = "Northern Gateway, Kalar"),
            hours = LocalizedText(ku = "ڕۆژانە • ٦:٠٠ بەیانی – ٨:٠٠ ئێوارە", en = "Daily • 6:00 AM – 8:00 PM"),
            phone = "188",
            isOpenNow = true,
            iconType = ServiceIconType.TRANSPORT,
            requiredDocs = listOf(
                LocalizedText(ku = "پشکنینی پزیشکی چاو و خوێن", en = "Medical & Vision Clearance"),
                LocalizedText(ku = "کارتی نیشتمانی و وێنە", en = "National ID & Passport Photos")
            )
        ),
        CityService(
            id = "university",
            category = ServiceCategory.EDUCATION,
            title = LocalizedText(ku = "زانکۆی گەرمیان", en = "University of Garmian"),
            subtitle = LocalizedText(ku = "کۆلێژەکان، کتێبخانە و کاروباری خوێندکاران", en = "Faculties, library & admissions"),
            description = LocalizedText(
                ku = "ناوەندی سەرەکی خوێندنی باڵا لە گەرمیان کە چەندین کۆلێژی زانستی، مرۆیی، پەروەردە و کشتوکاڵ و کتێبخانەیەکی دەوڵەمەند لەخۆدەگرێت.",
                en = "Premier higher education campus in Garmian hosting colleges of Science, Education, Medicine, Agriculture, and the Central Library."
            ),
            officeName = LocalizedText(ku = "کەمپی سەرەکی زانکۆی گەرمیان", en = "University of Garmian Main Campus"),
            address = LocalizedText(ku = "بەردەسوور، شەقامی زانکۆ، کەلار", en = "University Road, Bardasoor, Kalar"),
            hours = LocalizedText(ku = "یەکشەممە – پێنجشەممە • ٨:٣٠ – ٣:٠٠", en = "Sun – Thu • 8:30 AM – 3:00 PM"),
            phone = "+9647701400190",
            isOpenNow = true,
            iconType = ServiceIconType.UNIVERSITY,
            requiredDocs = listOf(
                LocalizedText(ku = "بڕوانامەی پۆلی ١٢ یان ناسنامەی زانکۆ", en = "High School Transcript / Student ID"),
                LocalizedText(ku = "پشکنینی تەندروستی و کارتی نیشتمانی", en = "Health Form & National ID")
            )
        )
    )

    val emergencyContacts: List<EmergencyContact> = listOf(
        EmergencyContact(
            id = "police",
            title = LocalizedText(ku = "پۆلیس", en = "Police"),
            number = "104",
            note = LocalizedText(ku = "فریاکەوتنی ئاسایش ٢٤/٧", en = "24/7 Emergency Response")
        ),
        EmergencyContact(
            id = "ambulance",
            title = LocalizedText(ku = "فریاکەوتنی پزیشکی", en = "Ambulance"),
            number = "122",
            note = LocalizedText(ku = "ئەمبوڵانسی خێرا", en = "Rapid Medical Dispatch")
        ),
        EmergencyContact(
            id = "fire",
            title = LocalizedText(ku = "بەرگری شارستانی", en = "Fire & Rescue"),
            number = "115",
            note = LocalizedText(ku = "ئاگرکوژێنەوە", en = "Civil Defense")
        ),
        EmergencyContact(
            id = "traffic",
            title = LocalizedText(ku = "هاتوچۆ", en = "Traffic"),
            number = "188",
            note = LocalizedText(ku = "ڕووداوی ڕێگاوبان", en = "Road Assistance")
        )
    )

    val cityFacts: List<CityFactSection> = listOf(
        CityFactSection(
            id = "overview",
            title = LocalizedText(ku = "دەربارەی کەلار", en = "About Kalar"),
            badge = LocalizedText(ku = "مێژوو و شوێن", en = "Overview"),
            body = LocalizedText(
                ku = "کەلار ناوەندی کارگێڕی ئیدارەی سەربەخۆی گەرمیانە لە هەرێمی کوردستان. شارەکە لەسەر کەناری ڕووباری سیروان هەڵکەوتووە و بە مێواندۆستی، کولتووری دێرین، بازاڕە زیندووەکان و گەشەی خێرای شارستانی دەناسرێتەوە.",
                en = "Kalar is the vibrant administrative center of the Garmian Administration in the Kurdistan Region of Iraq. Situated beside the fertile Sirwan River valley, Kalar blends warm Kurdish hospitality, deep historical heritage, bustling commerce, and modern urban growth."
            )
        ),
        CityFactSection(
            id = "climate",
            title = LocalizedText(ku = "کەشوهەوا و سروشت", en = "Climate & Landscape"),
            badge = LocalizedText(ku = "جوگرافیا", en = "Geography"),
            body = LocalizedText(
                ku = "دەشتی گەرمیان زستانێکی نەرم و باراناوی و بەهارێکی سەوز و ڕەنگاورەنگی هەیە، لە هاوینیشدا کەشوهەوایەکی گەرم و وشکی هەیە لەگەڵ شەوانی فێنکی کەنار ئاوی سیروان.",
                en = "Garmian enjoys mild, refreshing winters and lush green springs carpeted in wildflowers, followed by warm, sunny summers cooled in the evenings by breezes off the Sirwan River."
            )
        ),
        CityFactSection(
            id = "culture",
            title = LocalizedText(ku = "کولتوور و ژیانی ڕۆژانە", en = "Culture & Community"),
            badge = LocalizedText(ku = "کۆمەڵگا", en = "Community"),
            body = LocalizedText(
                ku = "زانکۆی گەرمیان، ناوەندە هونەرییەکان، پارکە گشتییەکان و بۆنە نەتەوەییەکان وەک نەورۆز لە قەڵای شێروانە، ڕۆحێکی گەرم و هاوچەرخیان بە ژیانی کۆمەڵایەتی شارەکە بەخشیوە.",
                en = "Anchored by the University of Garmian, cultural centers, family parks, and vibrant Nowruz celebrations around Sherwana Castle, Kalar thrives with youth energy and strong community bonds."
            )
        )
    )

    val neighborhoods: List<NeighborhoodItem> = listOf(
        NeighborhoodItem(
            id = "shirwana_q",
            name = LocalizedText(ku = "شێروانە", en = "Sherwana"),
            note = LocalizedText(ku = "گەڕەکی مێژوویی و نزیک قەڵا", en = "Historic quarter by the Castle")
        ),
        NeighborhoodItem(
            id = "bardasoor",
            name = LocalizedText(ku = "بەردەسوور", en = "Bardasoor"),
            note = LocalizedText(ku = "ناوەندی زانکۆ و گەشەی نوێ", en = "University & modern hub")
        ),
        NeighborhoodItem(
            id = "raparin",
            name = LocalizedText(ku = "ڕاپەڕین", en = "Raparin"),
            note = LocalizedText(ku = "گەڕەکی فراوان و خزمەتگوزاری", en = "Central residential & medical hub")
        ),
        NeighborhoodItem(
            id = "goran",
            name = LocalizedText(ku = "گۆران", en = "Goran"),
            note = LocalizedText(ku = "گەڕەکی ڕەسەن و پڕ جووڵە", en = "Lively traditional neighborhood")
        ),
        NeighborhoodItem(
            id = "azadi",
            name = LocalizedText(ku = "ئازادی", en = "Azadi"),
            note = LocalizedText(ku = "نزیک ناوەندی بازرگانی", en = "Close to central commerce")
        ),
        NeighborhoodItem(
            id = "kalar_kon",
            name = LocalizedText(ku = "کەلاری کۆن", en = "Old Kalar"),
            note = LocalizedText(ku = "یادەوەری و ڕەسەنایەتی شار", en = "Heritage core of the city")
        )
    )
}
