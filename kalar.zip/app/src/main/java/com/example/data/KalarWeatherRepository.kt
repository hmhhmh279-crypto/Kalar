package com.example.data

import com.example.model.KalarWeatherCondition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class KalarWeatherReading(
    val temperatureCelsius: Double,
    val weatherCode: Int,
    val condition: KalarWeatherCondition,
    val isDay: Boolean,
    val fetchedAtEpochMs: Long
)

/**
 * Lightweight, zero-ad, API-keyless weather fetcher for Kalar (34.6225°N, 45.3206°E)
 * using Open-Meteo over HTTPS. Paired with DataStore 15-minute caching in PreferencesRepository
 * so heavy traffic (200k+ users) incurs near-zero overhead and instant cold-start rendering.
 */
object KalarWeatherRepository {

    const val CACHE_TTL_MS: Long = 15L * 60L * 1000L
    private const val KALAR_WEATHER_URL =
        "https://api.open-meteo.com/v1/forecast?latitude=34.6225&longitude=45.3206&current=temperature_2m,weather_code,is_day&timezone=Asia%2FBaghdad"

    suspend fun fetchCurrentKalarWeather(): KalarWeatherReading? = withContext(Dispatchers.IO) {
        withTimeoutOrNull(5_000L) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(KALAR_WEATHER_URL)
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4_000
                    readTimeout = 4_000
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                }
                if (connection.responseCode !in 200..299) {
                    return@withTimeoutOrNull null
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                parseOpenMeteoResponse(body, System.currentTimeMillis())
            } catch (_: Exception) {
                null
            } finally {
                connection?.disconnect()
            }
        }
    }

    fun parseOpenMeteoResponse(jsonBody: String, nowEpochMs: Long): KalarWeatherReading? {
        return try {
            val root = JSONObject(jsonBody)
            val current = root.optJSONObject("current") ?: return null
            if (!current.has("temperature_2m")) return null
            val temp = current.getDouble("temperature_2m")
            if (temp.isNaN() || temp.isInfinite()) return null
            val code = current.optInt("weather_code", 0)
            val isDay = current.optInt("is_day", 1) == 1
            KalarWeatherReading(
                temperatureCelsius = temp,
                weatherCode = code,
                condition = conditionFromWmoCode(code),
                isDay = isDay,
                fetchedAtEpochMs = nowEpochMs
            )
        } catch (_: Exception) {
            null
        }
    }

    fun conditionFromWmoCode(code: Int): KalarWeatherCondition = when (code) {
        0 -> KalarWeatherCondition.CLEAR
        1, 2 -> KalarWeatherCondition.PARTLY_CLOUDY
        3 -> KalarWeatherCondition.CLOUDY
        45, 48 -> KalarWeatherCondition.FOG
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> KalarWeatherCondition.RAIN
        71, 73, 75, 77, 85, 86 -> KalarWeatherCondition.SNOW
        95, 96, 99 -> KalarWeatherCondition.STORM
        else -> KalarWeatherCondition.UNKNOWN
    }
}
