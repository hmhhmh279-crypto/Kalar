package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.KalarWeatherCondition
import com.example.model.KalarWeatherState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.kalarDataStore: DataStore<Preferences> by preferencesDataStore(name = "kalar_prefs")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("app_language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val SAVED_ITEMS = stringSetPreferencesKey("saved_items")
        val WEATHER_TEMP_C = doublePreferencesKey("weather_temp_c")
        val WEATHER_CODE = intPreferencesKey("weather_code")
        val WEATHER_IS_DAY = booleanPreferencesKey("weather_is_day")
        val WEATHER_UPDATED_MS = longPreferencesKey("weather_updated_ms")
    }

    val languageFlow: Flow<AppLanguage> = context.kalarDataStore.data.map { prefs ->
        when (prefs[Keys.LANGUAGE]) {
            AppLanguage.ENGLISH.code -> AppLanguage.ENGLISH
            else -> AppLanguage.KURDISH
        }
    }

    val themeModeFlow: Flow<AppThemeMode> = context.kalarDataStore.data.map { prefs ->
        when (prefs[Keys.THEME_MODE]) {
            AppThemeMode.LIGHT.name -> AppThemeMode.LIGHT
            AppThemeMode.DARK.name -> AppThemeMode.DARK
            else -> AppThemeMode.SYSTEM
        }
    }

    val savedIdsFlow: Flow<Set<String>> = context.kalarDataStore.data.map { prefs ->
        prefs[Keys.SAVED_ITEMS] ?: emptySet()
    }

    val cachedWeatherFlow: Flow<KalarWeatherState> = context.kalarDataStore.data.map { prefs ->
        val temp = prefs[Keys.WEATHER_TEMP_C]
        val code = prefs[Keys.WEATHER_CODE]
        KalarWeatherState(
            temperatureCelsius = temp,
            condition = if (code != null) {
                KalarWeatherRepository.conditionFromWmoCode(code)
            } else {
                KalarWeatherCondition.UNKNOWN
            },
            isDay = prefs[Keys.WEATHER_IS_DAY] ?: true,
            updatedAtEpochMs = prefs[Keys.WEATHER_UPDATED_MS] ?: 0L,
            isRefreshing = false
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.kalarDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.code
        }
    }

    suspend fun setThemeMode(themeMode: AppThemeMode) {
        context.kalarDataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = themeMode.name
        }
    }

    suspend fun toggleSavedItem(id: String) {
        context.kalarDataStore.edit { prefs ->
            val current = prefs[Keys.SAVED_ITEMS] ?: emptySet()
            prefs[Keys.SAVED_ITEMS] = if (id in current) current - id else current + id
        }
    }

    suspend fun saveWeatherReading(reading: KalarWeatherReading) {
        context.kalarDataStore.edit { prefs ->
            prefs[Keys.WEATHER_TEMP_C] = reading.temperatureCelsius
            prefs[Keys.WEATHER_CODE] = reading.weatherCode
            prefs[Keys.WEATHER_IS_DAY] = reading.isDay
            prefs[Keys.WEATHER_UPDATED_MS] = reading.fetchedAtEpochMs
        }
    }
}
