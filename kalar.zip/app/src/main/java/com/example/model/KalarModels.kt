package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable

enum class AppLanguage(val code: String) {
    KURDISH("ku"),
    ENGLISH("en")
}

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

@Immutable
data class LocalizedText(
    val ku: String,
    val en: String
) {
    fun get(language: AppLanguage): String = when (language) {
        AppLanguage.KURDISH -> ku
        AppLanguage.ENGLISH -> en
    }
}

enum class ServiceCategory {
    ALL,
    MUNICIPAL,
    HEALTH,
    UTILITIES,
    TRANSPORT,
    EDUCATION
}

enum class ServiceIconType {
    MUNICIPALITY,
    HOSPITAL,
    WATER_POWER,
    TRANSPORT,
    UNIVERSITY,
    CIVIL_RECORDS,
    PARKS,
    TRAFFIC
}

@Immutable
data class CityStat(
    val id: String,
    val label: LocalizedText,
    val value: LocalizedText,
    val detail: LocalizedText
)

@Immutable
data class CityLandmark(
    val id: String,
    val name: LocalizedText,
    val category: LocalizedText,
    val summary: LocalizedText,
    val fullDescription: LocalizedText,
    val location: LocalizedText,
    val visitingHours: LocalizedText,
    val highlights: List<LocalizedText>,
    @DrawableRes val imageRes: Int
)

@Immutable
data class CityService(
    val id: String,
    val category: ServiceCategory,
    val title: LocalizedText,
    val subtitle: LocalizedText,
    val description: LocalizedText,
    val officeName: LocalizedText,
    val address: LocalizedText,
    val hours: LocalizedText,
    val phone: String,
    val isOpenNow: Boolean,
    val iconType: ServiceIconType,
    val requiredDocs: List<LocalizedText>
)

@Immutable
data class EmergencyContact(
    val id: String,
    val title: LocalizedText,
    val number: String,
    val note: LocalizedText
)

@Immutable
data class CityFactSection(
    val id: String,
    val title: LocalizedText,
    val body: LocalizedText,
    val badge: LocalizedText
)

@Immutable
data class NeighborhoodItem(
    val id: String,
    val name: LocalizedText,
    val note: LocalizedText
)

// --- Dedicated Health Module Models ---

enum class HealthFacilityType {
    ALL,
    HOSPITAL,
    EMERGENCY,
    CLINIC_PHARMACY
}

@Immutable
data class HealthFacility(
    val id: String,
    val type: HealthFacilityType,
    val name: LocalizedText,
    val subtitle: LocalizedText,
    val description: LocalizedText,
    val address: LocalizedText,
    val hours: LocalizedText,
    val phone: String,
    val facebookUrl: String,
    val is24Hours: Boolean,
    val specialties: List<LocalizedText>
)

// --- Emergency & Official Directorate / Civic Links ---

enum class OfficialLinkType {
    TRAFFIC,
    EDUCATION,
    WEATHER,
    CONDOLENCES,
    OFFICIAL_PAGE
}

@Immutable
data class OfficialLinkItem(
    val id: String,
    val type: OfficialLinkType,
    val title: LocalizedText,
    val subtitle: LocalizedText,
    val description: LocalizedText,
    val badge: LocalizedText,
    val phone: String? = null,
    val url: String
)

// --- Unique Page Branding & Categorized Official Pages Models ---

enum class NewsCategory {
    ALL,
    LOCAL,
    MUNICIPAL,
    CULTURE_SPORTS
}

enum class NewsTabSection {
    FEED_TIMELINE,
    CATEGORIZED_PAGES
}

enum class OfficialPageCategory {
    ALL,
    HEALTH_MEDICAL,
    DIRECTORATES_WEATHER,
    COMMUNITY_OFFICIAL,
    LOCAL_NEWS
}

enum class OfficialPageIconType {
    HOSPITAL,
    CLINIC,
    EMERGENCY,
    TRAFFIC,
    EDUCATION,
    WEATHER,
    CONDOLENCES,
    OFFICIAL,
    NEWS_TV,
    NEWS_MEDIA
}

enum class PageEmblemStyle {
    RADIAL_CREST,
    DIAGONAL_BADGE,
    DOUBLE_RING,
    SHIELD_CREST
}

@Immutable
data class PageBrandIdentity(
    val id: String,
    val monogram: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val emblemStyle: PageEmblemStyle,
    val iconType: OfficialPageIconType
)

@Immutable
data class CategorizedFacebookPage(
    val id: String,
    val category: OfficialPageCategory,
    val name: LocalizedText,
    val subtitle: LocalizedText,
    val badge: LocalizedText,
    val url: String,
    val phone: String? = null,
    val brand: PageBrandIdentity
)

@Immutable
data class NewsSourcePage(
    val id: String,
    val name: LocalizedText,
    val tagline: LocalizedText,
    val url: String,
    val brand: PageBrandIdentity
)

@Immutable
data class NewsArticle(
    val id: String,
    val sourceId: String,
    val category: NewsCategory,
    val sourceName: LocalizedText,
    val publishedAgo: LocalizedText,
    val title: LocalizedText,
    val summary: LocalizedText,
    val body: LocalizedText,
    val url: String,
    val brand: PageBrandIdentity
)

// --- Top Header Weather & Dual Calendar Models ---

enum class KalarWeatherCondition {
    CLEAR,
    PARTLY_CLOUDY,
    CLOUDY,
    FOG,
    RAIN,
    STORM,
    SNOW,
    UNKNOWN
}

@Immutable
data class KalarCalendarDates(
    val weekdayKu: String,
    val weekdayEn: String,
    val kurdishDay: Int,
    val kurdishMonthKu: String,
    val kurdishMonthEn: String,
    val kurdishYear: Int,
    val gregorianDay: Int,
    val gregorianMonthKu: String,
    val gregorianMonthEn: String,
    val gregorianYear: Int
) {
    fun formatKurdishDate(language: AppLanguage): String = when (language) {
        AppLanguage.KURDISH -> "$kurdishDay $kurdishMonthKu $kurdishYear"
        AppLanguage.ENGLISH -> "$kurdishDay $kurdishMonthEn $kurdishYear"
    }

    fun formatGregorianDate(language: AppLanguage): String = when (language) {
        AppLanguage.KURDISH -> "$gregorianDay $gregorianMonthKu $gregorianYear"
        AppLanguage.ENGLISH -> "$gregorianDay $gregorianMonthEn $gregorianYear"
    }

    fun weekday(language: AppLanguage): String = when (language) {
        AppLanguage.KURDISH -> weekdayKu
        AppLanguage.ENGLISH -> weekdayEn
    }
}

@Immutable
data class KalarWeatherState(
    val temperatureCelsius: Double? = null,
    val condition: KalarWeatherCondition = KalarWeatherCondition.UNKNOWN,
    val isDay: Boolean = true,
    val updatedAtEpochMs: Long = 0L,
    val isRefreshing: Boolean = false
)

