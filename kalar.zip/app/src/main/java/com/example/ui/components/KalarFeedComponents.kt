package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Emergency
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.LiveTv
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.LocalPharmacy
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Thunderstorm
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Traffic
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbCloudy
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CategorizedFacebookPage
import com.example.model.KalarCalendarDates
import com.example.model.KalarWeatherCondition
import com.example.model.KalarWeatherState
import com.example.model.NewsArticle
import com.example.model.OfficialPageCategory
import com.example.model.OfficialPageIconType
import com.example.model.PageBrandIdentity
import com.example.model.PageEmblemStyle
import com.example.ui.KalarStrings
import java.util.Locale

fun officialPageCategoryIcon(category: OfficialPageCategory): ImageVector = when (category) {
    OfficialPageCategory.ALL -> Icons.Rounded.Apps
    OfficialPageCategory.HEALTH_MEDICAL -> Icons.Rounded.LocalHospital
    OfficialPageCategory.DIRECTORATES_WEATHER -> Icons.Rounded.AccountBalance
    OfficialPageCategory.COMMUNITY_OFFICIAL -> Icons.Rounded.Verified
    OfficialPageCategory.LOCAL_NEWS -> Icons.Rounded.Newspaper
}

fun officialPageIcon(iconType: OfficialPageIconType): ImageVector = when (iconType) {
    OfficialPageIconType.HOSPITAL -> Icons.Rounded.LocalHospital
    OfficialPageIconType.CLINIC -> Icons.Rounded.LocalPharmacy
    OfficialPageIconType.EMERGENCY -> Icons.Rounded.Emergency
    OfficialPageIconType.TRAFFIC -> Icons.Rounded.Traffic
    OfficialPageIconType.EDUCATION -> Icons.Rounded.School
    OfficialPageIconType.WEATHER -> Icons.Rounded.WbSunny
    OfficialPageIconType.CONDOLENCES -> Icons.Rounded.VolunteerActivism
    OfficialPageIconType.OFFICIAL -> Icons.Rounded.Verified
    OfficialPageIconType.NEWS_TV -> Icons.Rounded.LiveTv
    OfficialPageIconType.NEWS_MEDIA -> Icons.Rounded.Newspaper
}

@Composable
fun officialPageColors(iconType: OfficialPageIconType): Pair<Color, Color> {
    val scheme = MaterialTheme.colorScheme
    return when (iconType) {
        OfficialPageIconType.HOSPITAL,
        OfficialPageIconType.EMERGENCY -> scheme.errorContainer to scheme.onErrorContainer
        OfficialPageIconType.CLINIC -> scheme.secondaryContainer to scheme.onSecondaryContainer
        OfficialPageIconType.TRAFFIC,
        OfficialPageIconType.OFFICIAL -> scheme.primaryContainer to scheme.onPrimaryContainer
        OfficialPageIconType.EDUCATION,
        OfficialPageIconType.NEWS_MEDIA -> scheme.secondaryContainer to scheme.onSecondaryContainer
        OfficialPageIconType.WEATHER,
        OfficialPageIconType.NEWS_TV -> scheme.tertiaryContainer to scheme.onTertiaryContainer
        OfficialPageIconType.CONDOLENCES -> scheme.surfaceContainerHighest to scheme.onSurfaceVariant
    }
}

/**
 * High-performance vector profile avatar rendered purely on Canvas with zero bitmap decoding
 * overhead, ensuring each official page and news outlet shows its own unique logo/emblem.
 */
@Composable
fun PageProfileLogo(
    brand: PageBrandIdentity,
    contentDescription: String? = null,
    size: Dp = 46.dp,
    modifier: Modifier = Modifier
) {
    val primaryColor = remember(brand.primaryColorHex) { Color(brand.primaryColorHex) }
    val secondaryColor = remember(brand.secondaryColorHex) { Color(brand.secondaryColorHex) }
    val borderColor = MaterialTheme.colorScheme.surface
    val badgeSize = (size.value * 0.36f).coerceIn(14f, 24f).dp
    val monogramSizeSp = (size.value * (if (brand.monogram.length >= 3) 0.25f else 0.32f)).coerceIn(10f, 20f).sp

    Box(
        modifier = modifier
            .size(size)
            .testTag("page_logo_${brand.id}"),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .border(1.5.dp, Color.White.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(primaryColor, secondaryColor),
                        start = Offset.Zero,
                        end = Offset(this.size.width, this.size.height)
                    )
                )

                val w = this.size.width
                val h = this.size.height
                val accentTint = Color.White.copy(alpha = 0.16f)

                when (brand.emblemStyle) {
                    PageEmblemStyle.RADIAL_CREST -> {
                        drawCircle(
                            color = accentTint,
                            radius = w * 0.36f,
                            center = Offset(w * 0.78f, h * 0.22f)
                        )
                    }
                    PageEmblemStyle.DIAGONAL_BADGE -> {
                        drawLine(
                            color = accentTint,
                            start = Offset(0f, h * 0.85f),
                            end = Offset(w * 0.85f, 0f),
                            strokeWidth = w * 0.16f
                        )
                    }
                    PageEmblemStyle.DOUBLE_RING -> {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.28f),
                            radius = w * 0.42f,
                            style = Stroke(width = w * 0.055f)
                        )
                    }
                    PageEmblemStyle.SHIELD_CREST -> {
                        drawArc(
                            color = accentTint,
                            startAngle = -40f,
                            sweepAngle = 210f,
                            useCenter = true
                        )
                    }
                }
            }

            Text(
                text = brand.monogram,
                fontSize = monogramSizeSp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                maxLines = 1
            )
        }

        Surface(
            shape = CircleShape,
            color = primaryColor,
            border = BorderStroke(1.5.dp, borderColor),
            shadowElevation = 1.dp,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(badgeSize)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = officialPageIcon(brand.iconType),
                    contentDescription = contentDescription,
                    tint = Color.White,
                    modifier = Modifier.size(badgeSize * 0.62f)
                )
            }
        }
    }
}

@Composable
fun weatherConditionIcon(
    condition: KalarWeatherCondition,
    isDay: Boolean
): ImageVector = when (condition) {
    KalarWeatherCondition.CLEAR -> if (isDay) Icons.Rounded.WbSunny else Icons.Rounded.NightsStay
    KalarWeatherCondition.PARTLY_CLOUDY -> Icons.Rounded.WbCloudy
    KalarWeatherCondition.CLOUDY -> Icons.Rounded.Cloud
    KalarWeatherCondition.FOG -> Icons.Rounded.Grain
    KalarWeatherCondition.RAIN -> Icons.Rounded.WaterDrop
    KalarWeatherCondition.STORM -> Icons.Rounded.Thunderstorm
    KalarWeatherCondition.SNOW -> Icons.Rounded.AcUnit
    KalarWeatherCondition.UNKNOWN -> if (isDay) Icons.Rounded.WbSunny else Icons.Rounded.NightsStay
}

@Composable
fun KalarWeatherDateHeaderBanner(
    weatherState: KalarWeatherState,
    calendarDates: KalarCalendarDates,
    language: AppLanguage,
    strings: KalarStrings,
    onRefreshWeather: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tempText = remember(weatherState.temperatureCelsius) {
        weatherState.temperatureCelsius?.let { temp ->
            String.format(Locale.US, "%.1f°C", temp)
        } ?: "--°C"
    }
    val conditionLabel = remember(weatherState, strings) {
        when {
            weatherState.temperatureCelsius != null ->
                strings.weatherConditionLabels[weatherState.condition].orEmpty()
            weatherState.isRefreshing -> strings.weatherLoading
            else -> strings.weatherUnavailable
        }
    }

    val startTone = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
    val endTone = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.78f)

    Surface(
        shape = MaterialTheme.shapes.extraLarge,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)),
        tonalElevation = 2.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("top_weather_date_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(startTone, endTone)))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Exact Kalar Temperature + Weather Condition + Weekday + Refresh
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = weatherConditionIcon(weatherState.condition, weatherState.isDay),
                                contentDescription = conditionLabel,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.weatherKalarNow,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = tempText,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("kalar_temperature_text")
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                            ) {
                                Text(
                                    text = conditionLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.tertiaryContainer
                    ) {
                        Text(
                            text = calendarDates.weekday(language),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    IconButton(
                        onClick = onRefreshWeather,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_weather_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = strings.weatherRefreshDesc,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

            // Bottom Row: Dual Calendar Cards (Kurdish Day/Month/Year + Gregorian Day/Month/Year)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalendarPillBox(
                    label = strings.kurdishCalendarLabel,
                    dateText = calendarDates.formatKurdishDate(language),
                    icon = Icons.Rounded.CalendarMonth,
                    accentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("kurdish_calendar_date")
                )
                CalendarPillBox(
                    label = strings.gregorianCalendarLabel,
                    dateText = calendarDates.formatGregorianDate(language),
                    icon = Icons.Rounded.Today,
                    accentColor = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("gregorian_calendar_date")
                )
            }
        }
    }
}

@Composable
private fun CalendarPillBox(
    label: String,
    dateText: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.18f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
                Text(
                    text = dateText,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun FamilySafeBanner(
    label: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.28f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("family_safe_banner")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.VerifiedUser,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

@Composable
fun NewsTimelinePostCard(
    article: NewsArticle,
    language: AppLanguage,
    strings: KalarStrings,
    onReadClick: () -> Unit,
    onOpenFacebook: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accentColor = remember(article.brand.primaryColorHex) { Color(article.brand.primaryColorHex) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .testTag("timeline_post_${article.id}"),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Timeline rail indicator colored per news outlet identity
        Column(
            modifier = Modifier.fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 20.dp)
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(accentColor)
            )
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .weight(1f)
                    .padding(top = 6.dp)
                    .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
            )
        }

        Card(
            onClick = onReadClick,
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow
            ),
            border = BorderStroke(1.dp, accentColor.copy(alpha = 0.25f)),
            modifier = Modifier.weight(1f)
        ) {
            Column {
                // Page Unique Profile Logo, Exact Full Original Name & Timestamp Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        PageProfileLogo(
                            brand = article.brand,
                            contentDescription = article.sourceName.get(language),
                            size = 46.dp
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = article.sourceName.get(language),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Schedule,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = article.publishedAgo.get(language),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = accentColor.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = strings.newsCategoryLabels[article.category].orEmpty(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Clean Lightweight Body & Action Row (no generic landmark photo)
                Column(
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = article.title.get(language),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = article.summary.get(language),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onReadClick,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = strings.readMore,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        FilledTonalButton(
                            onClick = onOpenFacebook,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1.25f)
                                .testTag("timeline_open_fb_${article.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Public,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = strings.openLiveFacebook,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategorizedPageCard(
    page: CategorizedFacebookPage,
    language: AppLanguage,
    openLabel: String,
    callLabel: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val accentColor = remember(page.brand.primaryColorHex) { Color(page.brand.primaryColorHex) }

    Card(
        onClick = { openOfficialFacebookPage(context, page.url) },
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.24f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("categorized_page_${page.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PageProfileLogo(
                brand = page.brand,
                contentDescription = page.name.get(language),
                size = 48.dp
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = page.name.get(language),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = page.subtitle.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = accentColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = page.badge.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = accentColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (page.phone != null) {
                    FilledTonalIconButton(
                        onClick = { dialPhoneNumber(context, page.phone) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Call,
                            contentDescription = callLabel,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Button(
                    onClick = { openOfficialFacebookPage(context, page.url) },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text(
                        text = openLabel,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
