package com.example.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeliveryDining
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MedicalServices
import androidx.compose.material.icons.outlined.MiscellaneousServices
import androidx.compose.material.icons.outlined.Newspaper
import androidx.compose.material.icons.rounded.DeliveryDining
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.MiscellaneousServices
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.HealthFacilityDetailSheet
import com.example.ui.components.KalarDrawerContent
import com.example.ui.components.KalarTopBar
import com.example.ui.components.LandmarkDetailSheet
import com.example.ui.components.NewsArticleDetailSheet
import com.example.ui.components.ServiceDetailSheet
import com.example.ui.components.openAmadaDeliveryApp
import com.example.ui.screens.CityGuideScreen
import com.example.ui.screens.HealthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.OfficialPagesScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.stringsFor
import com.example.viewmodel.KalarUiState
import com.example.viewmodel.KalarViewModel
import kotlinx.coroutines.launch

const val ROUTE_HOME = "home"
const val ROUTE_CITY_GUIDE = "city_guide"
const val ROUTE_HEALTH = "health"
const val ROUTE_NEWS = "news"
const val ROUTE_OFFICIAL_PAGES = "official_pages"
const val ROUTE_DELIVERY_ACTION = "delivery_amada"
const val ROUTE_SERVICES = "services"
const val ROUTE_SETTINGS = "settings"

enum class KalarNavDestination(val route: String) {
    HOME(ROUTE_HOME),
    CITY_GUIDE(ROUTE_CITY_GUIDE),
    HEALTH(ROUTE_HEALTH),
    NEWS(ROUTE_NEWS),
    OFFICIAL_PAGES(ROUTE_OFFICIAL_PAGES),
    DELIVERY(ROUTE_DELIVERY_ACTION),
    SERVICES(ROUTE_SERVICES),
    SETTINGS(ROUTE_SETTINGS)
}

@Composable
fun KalarAppScaffold(
    uiState: KalarUiState,
    viewModel: KalarViewModel
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_HOME
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val strings = stringsFor(uiState.language)
    val allDestinations = KalarNavDestination.entries
    val bottomDestinations = listOf(
        KalarNavDestination.HOME,
        KalarNavDestination.HEALTH,
        KalarNavDestination.NEWS,
        KalarNavDestination.DELIVERY,
        KalarNavDestination.SERVICES
    )

    fun navigateTo(route: String) {
        if (route == ROUTE_DELIVERY_ACTION) {
            openAmadaDeliveryApp(context)
            return
        }
        if (currentRoute != route) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            KalarDrawerContent(
                destinations = allDestinations,
                currentRoute = currentRoute,
                language = uiState.language,
                strings = strings,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    navigateTo(route)
                },
                onSelectLanguage = viewModel::setLanguage
            )
        }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    KalarTopBar(
                        title = strings.appTitle,
                        subtitle = strings.regionSubtitle,
                        language = uiState.language,
                        openMenuDesc = strings.openMenuDesc,
                        onMenuClick = { scope.launch { drawerState.open() } },
                        onSelectLanguage = viewModel::setLanguage
                    )
                },
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                            tonalElevation = 2.dp
                        ) {
                            bottomDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                val label = when (dest) {
                                    KalarNavDestination.HOME -> strings.navHome
                                    KalarNavDestination.HEALTH -> strings.navHealth
                                    KalarNavDestination.NEWS -> strings.navNews
                                    KalarNavDestination.DELIVERY -> strings.navDelivery
                                    KalarNavDestination.SERVICES -> strings.navServices
                                    else -> ""
                                }
                                val icon = when (dest) {
                                    KalarNavDestination.HOME -> if (selected) Icons.Rounded.Home else Icons.Outlined.Home
                                    KalarNavDestination.HEALTH -> if (selected) Icons.Rounded.MedicalServices else Icons.Outlined.MedicalServices
                                    KalarNavDestination.NEWS -> if (selected) Icons.Rounded.Newspaper else Icons.Outlined.Newspaper
                                    KalarNavDestination.DELIVERY -> if (selected) Icons.Rounded.DeliveryDining else Icons.Outlined.DeliveryDining
                                    KalarNavDestination.SERVICES -> if (selected) Icons.Rounded.MiscellaneousServices else Icons.Outlined.MiscellaneousServices
                                    else -> Icons.Rounded.Home
                                }
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = { Icon(imageVector = icon, contentDescription = label) },
                                    label = {
                                        Text(
                                            text = label,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag("nav_bar_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            bottomDestinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                val label = when (dest) {
                                    KalarNavDestination.HOME -> strings.navHome
                                    KalarNavDestination.HEALTH -> strings.navHealth
                                    KalarNavDestination.NEWS -> strings.navNews
                                    KalarNavDestination.DELIVERY -> strings.navDelivery
                                    KalarNavDestination.SERVICES -> strings.navServices
                                    else -> ""
                                }
                                val icon = when (dest) {
                                    KalarNavDestination.HOME -> if (selected) Icons.Rounded.Home else Icons.Outlined.Home
                                    KalarNavDestination.HEALTH -> if (selected) Icons.Rounded.MedicalServices else Icons.Outlined.MedicalServices
                                    KalarNavDestination.NEWS -> if (selected) Icons.Rounded.Newspaper else Icons.Outlined.Newspaper
                                    KalarNavDestination.DELIVERY -> if (selected) Icons.Rounded.DeliveryDining else Icons.Outlined.DeliveryDining
                                    KalarNavDestination.SERVICES -> if (selected) Icons.Rounded.MiscellaneousServices else Icons.Outlined.MiscellaneousServices
                                    else -> Icons.Rounded.Home
                                }
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = { Icon(imageVector = icon, contentDescription = label) },
                                    label = { Text(text = label, maxLines = 1) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag("nav_rail_${dest.route}")
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_HOME,
                        enterTransition = {
                            fadeIn(animationSpec = tween(240)) + slideIntoContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                                animationSpec = tween(240)
                            ) { it / 10 }
                        },
                        exitTransition = { fadeOut(animationSpec = tween(200)) },
                        popEnterTransition = { fadeIn(animationSpec = tween(240)) },
                        popExitTransition = { fadeOut(animationSpec = tween(200)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(ROUTE_HOME) {
                            HomeScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectCategory = viewModel::selectCategory,
                                onSelectPageCategory = viewModel::selectPageCategory,
                                onOpenLandmark = viewModel::openLandmark,
                                onOpenService = viewModel::openService,
                                onOpenHealthFacility = viewModel::openHealthFacility,
                                onOpenNewsArticle = viewModel::openNewsArticle,
                                onNavigateToCityGuide = { navigateTo(ROUTE_CITY_GUIDE) },
                                onNavigateToHealth = { navigateTo(ROUTE_HEALTH) },
                                onNavigateToNews = {
                                    viewModel.selectNewsTab(com.example.model.NewsTabSection.FEED_TIMELINE)
                                    navigateTo(ROUTE_NEWS)
                                },
                                onNavigateToOfficialPages = { navigateTo(ROUTE_OFFICIAL_PAGES) },
                                onOpenAmadaDelivery = { openAmadaDeliveryApp(context) },
                                onNavigateToServices = { navigateTo(ROUTE_SERVICES) },
                                onRefreshWeather = { viewModel.refreshWeather(force = true) }
                            )
                        }
                        composable(ROUTE_CITY_GUIDE) {
                            CityGuideScreen(
                                uiState = uiState,
                                strings = strings,
                                onOpenLandmark = viewModel::openLandmark
                            )
                        }
                        composable(ROUTE_HEALTH) {
                            HealthScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectHealthType = viewModel::selectHealthType,
                                onOpenHealthFacility = viewModel::openHealthFacility
                            )
                        }
                        composable(ROUTE_NEWS) {
                            NewsScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectNewsTab = viewModel::selectNewsTab,
                                onSelectNewsCategory = viewModel::selectNewsCategory,
                                onSelectNewsSource = viewModel::selectNewsSource,
                                onSelectPageCategory = viewModel::selectPageCategory,
                                onPagesSearchQueryChange = viewModel::updatePagesSearchQuery,
                                onOpenNewsArticle = viewModel::openNewsArticle
                            )
                        }
                        composable(ROUTE_OFFICIAL_PAGES) {
                            OfficialPagesScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectPageCategory = viewModel::selectPageCategory,
                                onSearchQueryChange = viewModel::updatePagesSearchQuery
                            )
                        }
                        composable(ROUTE_SERVICES) {
                            ServicesScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectCategory = viewModel::selectCategory,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onOpenService = viewModel::openService
                            )
                        }
                        composable(ROUTE_SETTINGS) {
                            SettingsScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectLanguage = viewModel::setLanguage,
                                onSelectThemeMode = viewModel::setThemeMode,
                                onOpenLandmark = viewModel::openLandmark,
                                onOpenService = viewModel::openService,
                                onOpenHealthFacility = viewModel::openHealthFacility,
                                onOpenNewsArticle = viewModel::openNewsArticle
                            )
                        }
                    }
                }
            }
        }
    }

    uiState.selectedLandmark?.let { landmark ->
        LandmarkDetailSheet(
            landmark = landmark,
            language = uiState.language,
            strings = strings,
            isSaved = landmark.id in uiState.savedIds,
            onToggleSave = { viewModel.toggleSaved(landmark.id) },
            onDismiss = viewModel::dismissLandmark
        )
    }

    uiState.selectedService?.let { service ->
        ServiceDetailSheet(
            service = service,
            language = uiState.language,
            strings = strings,
            isSaved = service.id in uiState.savedIds,
            onToggleSave = { viewModel.toggleSaved(service.id) },
            onDismiss = viewModel::dismissService
        )
    }

    uiState.selectedHealthFacility?.let { facility ->
        HealthFacilityDetailSheet(
            facility = facility,
            language = uiState.language,
            strings = strings,
            isSaved = facility.id in uiState.savedIds,
            onToggleSave = { viewModel.toggleSaved(facility.id) },
            onDismiss = viewModel::dismissHealthFacility
        )
    }

    uiState.selectedNewsArticle?.let { article ->
        NewsArticleDetailSheet(
            article = article,
            language = uiState.language,
            strings = strings,
            isSaved = article.id in uiState.savedIds,
            onToggleSave = { viewModel.toggleSaved(article.id) },
            onDismiss = viewModel::dismissNewsArticle
        )
    }
}
