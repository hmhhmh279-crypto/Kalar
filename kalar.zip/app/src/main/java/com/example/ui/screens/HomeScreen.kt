package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.DeliveryDining
import androidx.compose.material.icons.rounded.DynamicFeed
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.LocationCity
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MedicalServices
import androidx.compose.material.icons.rounded.MiscellaneousServices
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.KalarRepository
import com.example.model.AppLanguage
import com.example.model.CityLandmark
import com.example.model.CityService
import com.example.model.CityStat
import com.example.model.HealthFacility
import com.example.model.NewsArticle
import com.example.model.OfficialPageCategory
import com.example.model.ServiceCategory
import com.example.ui.KalarStrings
import com.example.ui.components.CategorizedPageCard
import com.example.ui.components.EmergencyStrip
import com.example.ui.components.FamilySafeBanner
import com.example.ui.components.KalarWeatherDateHeaderBanner
import com.example.ui.components.NewsTimelinePostCard
import com.example.ui.components.PageProfileLogo
import com.example.ui.components.SectionHeader
import com.example.ui.components.dialPhoneNumber
import com.example.ui.components.healthFacilityIcon
import com.example.ui.components.officialPageCategoryIcon
import com.example.ui.components.openOfficialFacebookPage
import com.example.ui.components.serviceCategoryIcon
import com.example.ui.components.serviceIcon
import com.example.ui.components.serviceToneColors
import com.example.viewmodel.KalarUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: KalarUiState,
    strings: KalarStrings,
    onSelectCategory: (ServiceCategory) -> Unit,
    onSelectPageCategory: (OfficialPageCategory) -> Unit,
    onOpenLandmark: (CityLandmark) -> Unit,
    onOpenService: (CityService) -> Unit,
    onOpenHealthFacility: (HealthFacility) -> Unit,
    onOpenNewsArticle: (NewsArticle) -> Unit,
    onNavigateToCityGuide: () -> Unit,
    onNavigateToHealth: () -> Unit,
    onNavigateToNews: () -> Unit,
    onNavigateToOfficialPages: () -> Unit,
    onOpenAmadaDelivery: () -> Unit,
    onNavigateToServices: () -> Unit,
    onRefreshWeather: () -> Unit,
    modifier: Modifier = Modifier
) {
    val language = uiState.language
    val context = LocalContext.current

    val displayedServices = remember(uiState.services, uiState.selectedCategory) {
        if (uiState.selectedCategory == ServiceCategory.ALL) {
            uiState.services
        } else {
            uiState.services.filter { it.category == uiState.selectedCategory }
        }
    }
    val displayedPages = remember(uiState.categorizedPages, uiState.selectedPageCategory) {
        if (uiState.categorizedPages === KalarRepository.categorizedPages) {
            KalarRepository.pagesByCategory[uiState.selectedPageCategory] ?: uiState.categorizedPages
        } else {
            uiState.categorizedPages.filter { page ->
                uiState.selectedPageCategory == OfficialPageCategory.ALL ||
                    page.category == uiState.selectedPageCategory
            }
        }
    }
    val homeTimelineArticles = remember(uiState.newsArticles) { uiState.newsArticles.take(4) }
    val serviceRows = remember(displayedServices) { displayedServices.chunked(2) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 880.dp)
                .testTag("home_feed"),
            contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            // 0. Lightweight Top Weather & Dual Calendar (Kurdish + Gregorian) Header Banner
            item(key = "weather_date_header", contentType = "weather_date_header") {
                KalarWeatherDateHeaderBanner(
                    weatherState = uiState.weatherState,
                    calendarDates = uiState.calendarDates,
                    language = language,
                    strings = strings,
                    onRefreshWeather = onRefreshWeather,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // 1. Hero Banner with Real Sherwana Castle Photography
            item(key = "hero", contentType = "hero_banner") {
                KalarHeroCard(
                    strings = strings,
                    onExploreClick = onNavigateToCityGuide,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // 2. Quick Hub Shortcuts (Health, News, Amada Delivery, City Info)
            item(key = "quick_hub") {
                QuickModulesHub(
                    strings = strings,
                    onHealthClick = onNavigateToHealth,
                    onNewsClick = onNavigateToNews,
                    onAmadaClick = onOpenAmadaDelivery,
                    onCityInfoClick = onNavigateToCityGuide,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // 3. City Information Stats & Authentic Landmarks Photography
            item(key = "city_info_header") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = strings.sectionCityInfo,
                        subtitle = strings.sectionCityInfoSub,
                        icon = Icons.Rounded.LocationCity,
                        actionLabel = strings.viewAll,
                        onActionClick = onNavigateToCityGuide,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.cityStats, key = { it.id }) { stat ->
                            CityStatCard(stat = stat, language = language)
                        }
                    }
                }
            }

            item(key = "landmarks_row") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = strings.sectionLandmarks,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(uiState.landmarks, key = { it.id }) { landmark ->
                            LandmarkShowcaseCard(
                                landmark = landmark,
                                language = language,
                                onClick = { onOpenLandmark(landmark) }
                            )
                        }
                    }
                }
            }

            // 4. ALL Hospitals & Medical Centers (no 3-item cap!)
            item(key = "health_highlight") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = strings.sectionHealthTitle,
                        subtitle = strings.sectionHealthSub,
                        icon = Icons.Rounded.LocalHospital,
                        iconContainerColor = MaterialTheme.colorScheme.errorContainer,
                        iconTint = MaterialTheme.colorScheme.onErrorContainer,
                        actionLabel = strings.viewAll,
                        onActionClick = onNavigateToHealth,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.healthFacilities, key = { it.id }) { facility ->
                            HomeHealthCard(
                                facility = facility,
                                language = language,
                                strings = strings,
                                onClick = { onOpenHealthFacility(facility) }
                            )
                        }
                    }
                }
            }

            // 5. Dedicated News Feed Timeline Section (aggregated across all 9 news pages)
            item(key = "news_timeline_header") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader(
                        title = strings.newsTimelineTitle,
                        subtitle = strings.newsTimelineSub,
                        icon = Icons.Rounded.DynamicFeed,
                        iconContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        iconTint = MaterialTheme.colorScheme.onSecondaryContainer,
                        actionLabel = strings.viewAll,
                        onActionClick = onNavigateToNews,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    FamilySafeBanner(
                        label = strings.familySafeBadge,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            items(
                items = homeTimelineArticles,
                key = { "home_tl_${it.id}" },
                contentType = { "timeline_post" }
            ) { article ->
                NewsTimelinePostCard(
                    article = article,
                    language = language,
                    strings = strings,
                    onReadClick = { onOpenNewsArticle(article) },
                    onOpenFacebook = { openOfficialFacebookPage(context, article.url) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // 6. Separate Categorized Official Pages Section (all 20 pages by exact name & category)
            item(key = "categorized_pages_header") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = strings.categorizedPagesTitle,
                        subtitle = strings.categorizedPagesSub,
                        icon = Icons.Rounded.Verified,
                        iconContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        iconTint = MaterialTheme.colorScheme.onTertiaryContainer,
                        actionLabel = strings.viewAll,
                        onActionClick = onNavigateToOfficialPages,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(
                            items = OfficialPageCategory.entries,
                            key = { it.name },
                            contentType = { "page_category_chip" }
                        ) { category ->
                            val count = KalarRepository.pageCountsByCategory[category]
                                ?: uiState.categorizedPages.size
                            FilterChip(
                                selected = uiState.selectedPageCategory == category,
                                onClick = { onSelectPageCategory(category) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = officialPageCategoryIcon(category),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "${strings.officialPageCategoryLabels[category].orEmpty()} ($count)",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer
                                ),
                                modifier = Modifier.testTag("home_pages_filter_${category.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            items(
                items = displayedPages,
                key = { "home_cat_${it.id}" },
                contentType = { "categorized_page_card" }
            ) { page ->
                CategorizedPageCard(
                    page = page,
                    language = language,
                    openLabel = strings.openLink,
                    callLabel = strings.callOffice,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // 7. City Services Filter Chips & Grid (zero-lag flat items)
            item(key = "services_header") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = strings.sectionServices,
                        subtitle = strings.sectionServicesSub,
                        icon = Icons.Rounded.MiscellaneousServices,
                        actionLabel = strings.viewAll,
                        onActionClick = onNavigateToServices,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ServiceCategory.entries, key = { it.name }) { category ->
                            val selected = uiState.selectedCategory == category
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectCategory(category) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = serviceCategoryIcon(category),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = strings.categoryLabels[category].orEmpty(),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.testTag("home_filter_${category.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            items(serviceRows, key = { row -> "srv_" + row.joinToString("_") { it.id } }) { rowItems ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { service ->
                        ServiceTileCard(
                            service = service,
                            language = language,
                            openLabel = strings.openNow,
                            onClick = { onOpenService(service) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // 8. Emergency Hotlines Strip
            item(key = "emergency_strip") {
                EmergencyStrip(
                    title = strings.sectionEmergency,
                    contacts = uiState.emergencyContacts,
                    language = language,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}

@Composable
private fun QuickModulesHub(
    strings: KalarStrings,
    onHealthClick: () -> Unit,
    onNewsClick: () -> Unit,
    onAmadaClick: () -> Unit,
    onCityInfoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickHubTile(
                title = strings.navHealth,
                icon = Icons.Rounded.MedicalServices,
                containerColor = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer,
                onClick = onHealthClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("hub_health")
            )
            QuickHubTile(
                title = strings.navNews,
                icon = Icons.Rounded.Newspaper,
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                onClick = onNewsClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("hub_news")
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickHubTile(
                title = strings.amadaQuickLabel,
                icon = Icons.Rounded.DeliveryDining,
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                onClick = onAmadaClick,
                showExternalIcon = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("hub_delivery")
            )
            QuickHubTile(
                title = strings.navCityGuide,
                icon = Icons.Rounded.Explore,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                onClick = onCityInfoClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("hub_city_info")
            )
        }
    }
}

@Composable
private fun QuickHubTile(
    title: String,
    icon: ImageVector,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    showExternalIcon: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(contentColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = contentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (showExternalIcon) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun KalarHeroCard(
    strings: KalarStrings,
    onExploreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = MaterialTheme.shapes.extraLarge,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(248.dp)
            .testTag("hero_city_card")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = R.drawable.img_kalar_shirwana),
                contentDescription = strings.heroTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF2B1308).copy(alpha = 0.2f),
                                Color(0xFF2B1308).copy(alpha = 0.88f)
                            )
                        )
                    )
            )

            Surface(
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.4f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WbSunny,
                        contentDescription = null,
                        tint = Color(0xFFF6C166),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = strings.heroBadge,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(20.dp)
            ) {
                Text(
                    text = strings.greetingHeader,
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFFFFD8B0)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = strings.heroTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.heroSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onExploreClick,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = Color(0xFF281800)
                    ),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
                    modifier = Modifier.testTag("hero_explore_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Explore,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.exploreCityCta,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeHealthCard(
    facility: HealthFacility,
    language: AppLanguage,
    strings: KalarStrings,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.25f)),
        modifier = Modifier
            .width(276.dp)
            .testTag("home_health_${facility.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = healthFacilityIcon(facility.type),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (facility.is24Hours) strings.open24Hours else strings.openNow,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                FilledTonalIconButton(
                    onClick = { dialPhoneNumber(context, facility.phone) },
                    modifier = Modifier
                        .size(36.dp)
                        .minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = strings.callOffice,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PageProfileLogo(
                    brand = KalarRepository.brandForId(facility.id),
                    contentDescription = facility.name.get(language),
                    size = 42.dp
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = facility.name.get(language),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = facility.subtitle.get(language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            OutlinedButton(
                onClick = { openOfficialFacebookPage(context, facility.facebookUrl) },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Rounded.Public,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.openSourcePage, style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}


@Composable
private fun CityStatCard(
    stat: CityStat,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = modifier.width(148.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = stat.label.get(language),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = stat.value.get(language),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = stat.detail.get(language),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LandmarkShowcaseCard(
    landmark: CityLandmark,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .width(264.dp)
            .testTag("landmark_card_${landmark.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
            ) {
                Image(
                    painter = painterResource(id = landmark.imageRes),
                    contentDescription = landmark.name.get(language),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = landmark.category.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = landmark.name.get(language),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = landmark.summary.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = landmark.location.get(language),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun ServiceTileCard(
    service: CityService,
    language: AppLanguage,
    openLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bgTone, fgTone) = serviceToneColors(service.iconType)

    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = modifier
            .height(166.dp)
            .testTag("service_card_${service.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(MaterialTheme.shapes.small)
                        .background(bgTone),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = serviceIcon(service.iconType),
                        contentDescription = null,
                        tint = fgTone,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary)
                        )
                        Text(
                            text = openLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            Column {
                Text(
                    text = service.title.get(language),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = service.subtitle.get(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
