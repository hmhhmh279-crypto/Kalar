package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DynamicFeed
import androidx.compose.material.icons.rounded.Newspaper
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.KalarRepository
import com.example.model.NewsArticle
import com.example.model.NewsCategory
import com.example.model.NewsTabSection
import com.example.model.OfficialPageCategory
import com.example.ui.KalarStrings
import com.example.ui.components.CategorizedPageCard
import com.example.ui.components.FamilySafeBanner
import com.example.ui.components.NewsTimelinePostCard
import com.example.ui.components.PageProfileLogo
import com.example.ui.components.SectionHeader
import com.example.ui.components.newsCategoryIcon
import com.example.ui.components.officialPageCategoryIcon
import com.example.ui.components.openOfficialFacebookPage
import com.example.viewmodel.KalarUiState

@Composable
fun NewsScreen(
    uiState: KalarUiState,
    strings: KalarStrings,
    onSelectNewsTab: (NewsTabSection) -> Unit,
    onSelectNewsCategory: (NewsCategory) -> Unit,
    onSelectNewsSource: (String?) -> Unit,
    onSelectPageCategory: (OfficialPageCategory) -> Unit,
    onPagesSearchQueryChange: (String) -> Unit,
    onOpenNewsArticle: (NewsArticle) -> Unit,
    modifier: Modifier = Modifier
) {
    val language = uiState.language
    val context = LocalContext.current
    val groupedPages = remember(uiState.filteredCategorizedPages) {
        uiState.filteredCategorizedPages.groupBy { it.category }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 880.dp)
                .testTag("news_screen"),
            contentPadding = PaddingValues(vertical = 14.dp, horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "news_header") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.secondaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (uiState.selectedNewsTab == NewsTabSection.FEED_TIMELINE) {
                                Icons.Rounded.DynamicFeed
                            } else {
                                Icons.Rounded.Verified
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = if (uiState.selectedNewsTab == NewsTabSection.FEED_TIMELINE) {
                                strings.newsTimelineTitle
                            } else {
                                strings.categorizedPagesTitle
                            },
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (uiState.selectedNewsTab == NewsTabSection.FEED_TIMELINE) {
                                strings.newsTimelineSub
                            } else {
                                strings.categorizedPagesSub
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Segmented Switcher: Dedicated News Feed Timeline vs Categorized Official Pages
            item(key = "news_tab_switcher") {
                NewsSectionSwitcher(
                    selectedTab = uiState.selectedNewsTab,
                    feedLabel = "${strings.newsFeedTabLabel} (${uiState.newsArticles.size})",
                    pagesLabel = "${strings.categorizedPagesTabLabel} (${uiState.categorizedPages.size})",
                    onSelectTab = onSelectNewsTab
                )
            }

            item(key = "news_family_safe") {
                FamilySafeBanner(label = strings.familySafeBadge)
            }

            if (uiState.selectedNewsTab == NewsTabSection.FEED_TIMELINE) {
                // Source Page Filter Chips (All Sources + 9 exact news pages)
                item(key = "news_source_filters") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item(key = "source_all") {
                            FilterChip(
                                selected = uiState.selectedNewsSourceId == null,
                                onClick = { onSelectNewsSource(null) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Apps,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "${strings.allSourcesLabel} (${uiState.newsSources.size})",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.testTag("timeline_source_all")
                            )
                        }
                        items(
                            items = uiState.newsSources,
                            key = { it.id },
                            contentType = { "source_chip" }
                        ) { source ->
                            FilterChip(
                                selected = uiState.selectedNewsSourceId == source.id,
                                onClick = {
                                    val next = if (uiState.selectedNewsSourceId == source.id) null else source.id
                                    onSelectNewsSource(next)
                                },
                                leadingIcon = {
                                    PageProfileLogo(
                                        brand = source.brand,
                                        contentDescription = null,
                                        size = 20.dp
                                    )
                                },
                                label = {
                                    Text(
                                        text = source.name.get(language),
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.testTag("timeline_source_${source.id}")
                            )
                        }
                    }
                }

                // Category Filter Chips
                item(key = "news_filters") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(NewsCategory.entries, key = { it.name }) { category ->
                            FilterChip(
                                selected = uiState.selectedNewsCategory == category,
                                onClick = { onSelectNewsCategory(category) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = newsCategoryIcon(category),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = strings.newsCategoryLabels[category].orEmpty(),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.testTag("news_filter_${category.name.lowercase()}")
                            )
                        }
                    }
                }

                // Clean Aggregated Timeline Feed
                if (uiState.filteredNews.isEmpty()) {
                    item(key = "timeline_empty") {
                        Surface(
                            shape = MaterialTheme.shapes.large,
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.SearchOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(38.dp)
                                )
                                Text(
                                    text = strings.noServicesFound,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                OutlinedButton(
                                    onClick = {
                                        onSelectNewsCategory(NewsCategory.ALL)
                                        onSelectNewsSource(null)
                                    }
                                ) {
                                    Text(strings.clearSearch)
                                }
                            }
                        }
                    }
                } else {
                    items(
                        items = uiState.filteredNews,
                        key = { it.id },
                        contentType = { "timeline_post" }
                    ) { article ->
                        NewsTimelinePostCard(
                            article = article,
                            language = language,
                            strings = strings,
                            onReadClick = { onOpenNewsArticle(article) },
                            onOpenFacebook = { openOfficialFacebookPage(context, article.url) }
                        )
                    }
                }
            } else {
                // Separate Categorized Official Pages Section
                item(key = "pages_search") {
                    OutlinedTextField(
                        value = uiState.pagesSearchQuery,
                        onValueChange = onPagesSearchQueryChange,
                        placeholder = {
                            Text(
                                text = strings.searchPagesPlaceholder,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        },
                        leadingIcon = {
                            Icon(imageVector = Icons.Rounded.Search, contentDescription = null)
                        },
                        trailingIcon = {
                            if (uiState.pagesSearchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = { onPagesSearchQueryChange("") },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = strings.clearSearch
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.large,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("news_pages_search_input")
                    )
                }

                item(key = "pages_category_chips") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(
                            items = OfficialPageCategory.entries,
                            key = { it.name },
                            contentType = { "page_category_chip" }
                        ) { category ->
                            val count = KalarRepository.pageCountsByCategory[category]
                                ?: uiState.categorizedPages.size
                            FilterChip(
                                selected = uiState.selectedPageCategory == category,
                                onClick = { onSelectPageCategory(category) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = officialPageCategoryIcon(category),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = "${strings.officialPageCategoryLabels[category].orEmpty()} ($count)",
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.testTag("news_pages_filter_${category.name.lowercase()}")
                            )
                        }
                    }
                }

                if (uiState.filteredCategorizedPages.isEmpty()) {
                    item(key = "pages_empty") {
                        Surface(
                            shape = MaterialTheme.shapes.large,
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.SearchOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(38.dp)
                                )
                                Text(
                                    text = strings.noPagesFound,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                OutlinedButton(
                                    onClick = {
                                        onPagesSearchQueryChange("")
                                        onSelectPageCategory(OfficialPageCategory.ALL)
                                    }
                                ) {
                                    Text(strings.clearSearch)
                                }
                            }
                        }
                    }
                } else {
                    OfficialPageCategory.entries
                        .filter { it != OfficialPageCategory.ALL }
                        .forEach { category ->
                            val pages = groupedPages[category].orEmpty()
                            if (pages.isNotEmpty()) {
                                item(key = "cat_hdr_${category.name}", contentType = "section_header") {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    SectionHeader(
                                        title = "${strings.officialPageCategoryLabels[category].orEmpty()} (${pages.size})",
                                        icon = officialPageCategoryIcon(category)
                                    )
                                }
                                items(
                                    items = pages,
                                    key = { it.id },
                                    contentType = { "categorized_page_card" }
                                ) { page ->
                                    CategorizedPageCard(
                                        page = page,
                                        language = language,
                                        openLabel = strings.openLink,
                                        callLabel = strings.callOffice
                                    )
                                }
                            }
                        }
                }
            }
        }
    }
}

@Composable
private fun NewsSectionSwitcher(
    selectedTab: NewsTabSection,
    feedLabel: String,
    pagesLabel: String,
    onSelectTab: (NewsTabSection) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            NewsTabPill(
                label = feedLabel,
                icon = Icons.Rounded.DynamicFeed,
                selected = selectedTab == NewsTabSection.FEED_TIMELINE,
                onClick = { onSelectTab(NewsTabSection.FEED_TIMELINE) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("tab_news_feed")
            )
            NewsTabPill(
                label = pagesLabel,
                icon = Icons.Rounded.Verified,
                selected = selectedTab == NewsTabSection.CATEGORIZED_PAGES,
                onClick = { onSelectTab(NewsTabSection.CATEGORIZED_PAGES) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("tab_categorized_pages")
            )
        }
    }
}

@Composable
private fun NewsTabPill(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tabBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tabFg"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = contentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
