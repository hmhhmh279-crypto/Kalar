package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.KalarRepository
import com.example.model.OfficialPageCategory
import com.example.ui.KalarStrings
import com.example.ui.components.CategorizedPageCard
import com.example.ui.components.FamilySafeBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.officialPageCategoryIcon
import com.example.viewmodel.KalarUiState

@Composable
fun OfficialPagesScreen(
    uiState: KalarUiState,
    strings: KalarStrings,
    onSelectPageCategory: (OfficialPageCategory) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val language = uiState.language
    val filteredPages = uiState.filteredCategorizedPages
    val groupedPages = remember(filteredPages) {
        filteredPages.groupBy { it.category }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 880.dp)
                .testTag("official_pages_screen"),
            contentPadding = PaddingValues(vertical = 14.dp, horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "pages_header") {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Verified,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = strings.categorizedPagesTitle,
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = strings.categorizedPagesSub,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item(key = "pages_safe_banner") {
                FamilySafeBanner(label = strings.familySafeBadge)
            }

            item(key = "pages_search") {
                OutlinedTextField(
                    value = uiState.pagesSearchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = strings.searchPagesPlaceholder,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    leadingIcon = {
                        Icon(imageVector = Icons.Rounded.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (uiState.pagesSearchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onSearchQueryChange("") },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = strings.clearSearch
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.large,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pages_search_input")
                )
            }

            item(key = "pages_category_chips") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(
                        items = OfficialPageCategory.entries,
                        key = { it.name },
                        contentType = { "page_category_chip" }
                    ) { category ->
                        val count = KalarRepository.pageCountsByCategory[category]
                            ?: uiState.categorizedPages.size
                        val labelText = "${strings.officialPageCategoryLabels[category].orEmpty()} ($count)"
                        FilterChip(
                            selected = uiState.selectedPageCategory == category,
                            onClick = { onSelectPageCategory(category) },
                            leadingIcon = {
                                Icon(
                                    imageVector = officialPageCategoryIcon(category),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = labelText,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("pages_filter_${category.name.lowercase()}")
                        )
                    }
                }
            }

            if (filteredPages.isEmpty()) {
                item(key = "pages_empty") {
                    Surface(
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = strings.noPagesFound,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            OutlinedButton(
                                onClick = {
                                    onSearchQueryChange("")
                                    onSelectPageCategory(OfficialPageCategory.ALL)
                                }
                            ) {
                                Text(strings.clearSearch)
                            }
                        }
                    }
                }
            } else {
                OfficialPageCategory.entries
                    .filter { it != OfficialPageCategory.ALL }
                    .forEach { category ->
                        val pagesInCategory = groupedPages[category].orEmpty()
                        if (pagesInCategory.isNotEmpty()) {
                            item(key = "group_hdr_${category.name}", contentType = "section_header") {
                                Spacer(modifier = Modifier.height(2.dp))
                                SectionHeader(
                                    title = "${strings.officialPageCategoryLabels[category].orEmpty()} (${pagesInCategory.size})",
                                    icon = officialPageCategoryIcon(category)
                                )
                            }
                            items(
                                items = pagesInCategory,
                                key = { it.id },
                                contentType = { "categorized_page_card" }
                            ) { page ->
                                CategorizedPageCard(
                                    page = page,
                                    language = language,
                                    openLabel = strings.openLink,
                                    callLabel = strings.callOffice
                                )
                            }
                        }
                    }
            }
        }
    }
}
