package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kalar / Garmian Warm Sandstone, Terracotta & Sirwan River Palette

// Light Theme Tokens
val KalarPrimaryLight = Color(0xFFA9431E)        // Baked Shirwana Brick Terracotta
val KalarOnPrimaryLight = Color(0xFFFFFFFF)
val KalarPrimaryContainerLight = Color(0xFFFFDBD0)
val KalarOnPrimaryContainerLight = Color(0xFF3B0D00)

val KalarSecondaryLight = Color(0xFF1A655D)      // Sirwan River Deep Emerald
val KalarOnSecondaryLight = Color(0xFFFFFFFF)
val KalarSecondaryContainerLight = Color(0xFFA8F1E5)
val KalarOnSecondaryContainerLight = Color(0xFF00201C)

val KalarTertiaryLight = Color(0xFFB37914)       // Garmian Golden Sunlight
val KalarOnTertiaryLight = Color(0xFFFFFFFF)
val KalarTertiaryContainerLight = Color(0xFFFFDEA8)
val KalarOnTertiaryContainerLight = Color(0xFF281800)

val KalarErrorLight = Color(0xFFBA1A1A)
val KalarOnErrorLight = Color(0xFFFFFFFF)
val KalarErrorContainerLight = Color(0xFFFFDAD6)
val KalarOnErrorContainerLight = Color(0xFF410002)

val KalarBackgroundLight = Color(0xFFFCF8F3)     // Warm Limestone Parchment
val KalarOnBackgroundLight = Color(0xFF211A16)
val KalarSurfaceLight = Color(0xFFFCF8F3)
val KalarOnSurfaceLight = Color(0xFF211A16)
val KalarSurfaceVariantLight = Color(0xFFF3E4DC)
val KalarOnSurfaceVariantLight = Color(0xFF52443C)
val KalarOutlineLight = Color(0xFF84746B)
val KalarOutlineVariantLight = Color(0xFFD7C2B8)
val KalarSurfaceContainerLowestLight = Color(0xFFFFFFFF)
val KalarSurfaceContainerLowLight = Color(0xFFF8F1EA)
val KalarSurfaceContainerLight = Color(0xFFF2EAE2)
val KalarSurfaceContainerHighLight = Color(0xFFECE2D9)
val KalarSurfaceContainerHighestLight = Color(0xFFE6DBD1)

// Dark Theme Tokens
val KalarPrimaryDark = Color(0xFFFFB59D)
val KalarOnPrimaryDark = Color(0xFF5E1B02)
val KalarPrimaryContainerDark = Color(0xFF832D0C)
val KalarOnPrimaryContainerDark = Color(0xFFFFDBD0)

val KalarSecondaryDark = Color(0xFF8CD5C9)
val KalarOnSecondaryDark = Color(0xFF003732)
val KalarSecondaryContainerDark = Color(0xFF005049)
val KalarOnSecondaryContainerDark = Color(0xFFA8F1E5)

val KalarTertiaryDark = Color(0xFFF6C166)
val KalarOnTertiaryDark = Color(0xFF432B00)
val KalarTertiaryContainerDark = Color(0xFF604000)
val KalarOnTertiaryContainerDark = Color(0xFFFFDEA8)

val KalarErrorDark = Color(0xFFFFB4AB)
val KalarOnErrorDark = Color(0xFF690005)
val KalarErrorContainerDark = Color(0xFF93000A)
val KalarOnErrorContainerDark = Color(0xFFFFDAD6)

val KalarBackgroundDark = Color(0xFF18120F)      // Warm Sandstone Night
val KalarOnBackgroundDark = Color(0xFFEDE0D9)
val KalarSurfaceDark = Color(0xFF18120F)
val KalarOnSurfaceDark = Color(0xFFEDE0D9)
val KalarSurfaceVariantDark = Color(0xFF52443C)
val KalarOnSurfaceVariantDark = Color(0xFFD7C2B8)
val KalarOutlineDark = Color(0xFF9F8D84)
val KalarOutlineVariantDark = Color(0xFF52443C)
val KalarSurfaceContainerLowestDark = Color(0xFF120D0A)
val KalarSurfaceContainerLowDark = Color(0xFF211A16)
val KalarSurfaceContainerDark = Color(0xFF251E1A)
val KalarSurfaceContainerHighDark = Color(0xFF302824)
val KalarSurfaceContainerHighestDark = Color(0xFF3B322E)
