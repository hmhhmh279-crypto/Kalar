package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KalarDarkColorScheme = darkColorScheme(
    primary = KalarPrimaryDark,
    onPrimary = KalarOnPrimaryDark,
    primaryContainer = KalarPrimaryContainerDark,
    onPrimaryContainer = KalarOnPrimaryContainerDark,
    secondary = KalarSecondaryDark,
    onSecondary = KalarOnSecondaryDark,
    secondaryContainer = KalarSecondaryContainerDark,
    onSecondaryContainer = KalarOnSecondaryContainerDark,
    tertiary = KalarTertiaryDark,
    onTertiary = KalarOnTertiaryDark,
    tertiaryContainer = KalarTertiaryContainerDark,
    onTertiaryContainer = KalarOnTertiaryContainerDark,
    error = KalarErrorDark,
    onError = KalarOnErrorDark,
    errorContainer = KalarErrorContainerDark,
    onErrorContainer = KalarOnErrorContainerDark,
    background = KalarBackgroundDark,
    onBackground = KalarOnBackgroundDark,
    surface = KalarSurfaceDark,
    onSurface = KalarOnSurfaceDark,
    surfaceVariant = KalarSurfaceVariantDark,
    onSurfaceVariant = KalarOnSurfaceVariantDark,
    outline = KalarOutlineDark,
    outlineVariant = KalarOutlineVariantDark,
    surfaceContainerLowest = KalarSurfaceContainerLowestDark,
    surfaceContainerLow = KalarSurfaceContainerLowDark,
    surfaceContainer = KalarSurfaceContainerDark,
    surfaceContainerHigh = KalarSurfaceContainerHighDark,
    surfaceContainerHighest = KalarSurfaceContainerHighestDark
)

private val KalarLightColorScheme = lightColorScheme(
    primary = KalarPrimaryLight,
    onPrimary = KalarOnPrimaryLight,
    primaryContainer = KalarPrimaryContainerLight,
    onPrimaryContainer = KalarOnPrimaryContainerLight,
    secondary = KalarSecondaryLight,
    onSecondary = KalarOnSecondaryLight,
    secondaryContainer = KalarSecondaryContainerLight,
    onSecondaryContainer = KalarOnSecondaryContainerLight,
    tertiary = KalarTertiaryLight,
    onTertiary = KalarOnTertiaryLight,
    tertiaryContainer = KalarTertiaryContainerLight,
    onTertiaryContainer = KalarOnTertiaryContainerLight,
    error = KalarErrorLight,
    onError = KalarOnErrorLight,
    errorContainer = KalarErrorContainerLight,
    onErrorContainer = KalarOnErrorContainerLight,
    background = KalarBackgroundLight,
    onBackground = KalarOnBackgroundLight,
    surface = KalarSurfaceLight,
    onSurface = KalarOnSurfaceLight,
    surfaceVariant = KalarSurfaceVariantLight,
    onSurfaceVariant = KalarOnSurfaceVariantLight,
    outline = KalarOutlineLight,
    outlineVariant = KalarOutlineVariantLight,
    surfaceContainerLowest = KalarSurfaceContainerLowestLight,
    surfaceContainerLow = KalarSurfaceContainerLowLight,
    surfaceContainer = KalarSurfaceContainerLight,
    surfaceContainerHigh = KalarSurfaceContainerHighLight,
    surfaceContainerHighest = KalarSurfaceContainerHighestLight
)

@Composable
fun KalarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    isKurdish: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KalarDarkColorScheme else KalarLightColorScheme
    val typography = buildKalarTypography(isKurdish = isKurdish)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = KalarShapes,
        content = content
    )
}
