package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.KalarCalendarHelper
import com.example.data.KalarRepository
import com.example.data.KalarWeatherRepository
import com.example.data.PreferencesRepository
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.CategorizedFacebookPage
import com.example.model.CityFactSection
import com.example.model.CityLandmark
import com.example.model.CityService
import com.example.model.CityStat
import com.example.model.EmergencyContact
import com.example.model.HealthFacility
import com.example.model.HealthFacilityType
import com.example.model.KalarCalendarDates
import com.example.model.KalarWeatherState
import com.example.model.NeighborhoodItem
import com.example.model.NewsArticle
import com.example.model.NewsCategory
import com.example.model.NewsSourcePage
import com.example.model.NewsTabSection
import com.example.model.OfficialLinkItem
import com.example.model.OfficialPageCategory
import com.example.model.ServiceCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

@Immutable
data class KalarUiState(
    val language: AppLanguage = AppLanguage.KURDISH,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val selectedCategory: ServiceCategory = ServiceCategory.ALL,
    val selectedHealthType: HealthFacilityType = HealthFacilityType.ALL,
    val selectedNewsCategory: NewsCategory = NewsCategory.ALL,
    val selectedNewsTab: NewsTabSection = NewsTabSection.FEED_TIMELINE,
    val selectedNewsSourceId: String? = null,
    val selectedPageCategory: OfficialPageCategory = OfficialPageCategory.ALL,
    val searchQuery: String = "",
    val pagesSearchQuery: String = "",
    val selectedLandmark: CityLandmark? = null,
    val selectedService: CityService? = null,
    val selectedHealthFacility: HealthFacility? = null,
    val selectedNewsArticle: NewsArticle? = null,
    val savedIds: Set<String> = emptySet(),
    val calendarDates: KalarCalendarDates = KalarCalendarHelper.currentKalarDates(),
    val weatherState: KalarWeatherState = KalarWeatherState(),
    val cityStats: List<CityStat> = KalarRepository.cityStats,
    val landmarks: List<CityLandmark> = KalarRepository.landmarks,
    val services: List<CityService> = KalarRepository.services,
    val emergencyContacts: List<EmergencyContact> = KalarRepository.emergencyContacts,
    val cityFacts: List<CityFactSection> = KalarRepository.cityFacts,
    val neighborhoods: List<NeighborhoodItem> = KalarRepository.neighborhoods,
    val healthFacilities: List<HealthFacility> = KalarRepository.healthFacilities,
    val officialLinks: List<OfficialLinkItem> = KalarRepository.officialLinks,
    val newsSources: List<NewsSourcePage> = KalarRepository.newsSources,
    val newsArticles: List<NewsArticle> = KalarRepository.newsArticles,
    val categorizedPages: List<CategorizedFacebookPage> = KalarRepository.categorizedPages
) {
    // Pre-computed once per state emission rather than re-filtering inside Compose scroll/layout frames.
    val filteredServices: List<CityService> = filterServices(services, selectedCategory, searchQuery)

    val filteredHealthFacilities: List<HealthFacility> =
        if (selectedHealthType == HealthFacilityType.ALL) {
            healthFacilities
        } else {
            healthFacilities.filter { it.type == selectedHealthType }
        }

    val filteredNews: List<NewsArticle> = filterNews(
        allArticles = newsArticles,
        category = selectedNewsCategory,
        sourceId = selectedNewsSourceId
    )

    val filteredCategorizedPages: List<CategorizedFacebookPage> = filterPages(
        allPages = categorizedPages,
        category = selectedPageCategory,
        queryText = pagesSearchQuery
    )
}

private fun filterServices(
    services: List<CityService>,
    category: ServiceCategory,
    searchQuery: String
): List<CityService> {
    val query = searchQuery.trim().lowercase()
    if (category == ServiceCategory.ALL && query.isEmpty()) return services
    return services.filter { service ->
        val matchesCategory = category == ServiceCategory.ALL || service.category == category
        val matchesQuery = query.isEmpty() ||
            service.title.ku.lowercase().contains(query) ||
            service.title.en.lowercase().contains(query) ||
            service.subtitle.ku.lowercase().contains(query) ||
            service.subtitle.en.lowercase().contains(query) ||
            service.officeName.ku.lowercase().contains(query) ||
            service.officeName.en.lowercase().contains(query)
        matchesCategory && matchesQuery
    }
}

private fun filterNews(
    allArticles: List<NewsArticle>,
    category: NewsCategory,
    sourceId: String?
): List<NewsArticle> {
    if (allArticles === KalarRepository.newsArticles) {
        if (category == NewsCategory.ALL && sourceId == null) return allArticles
        if (sourceId != null && category == NewsCategory.ALL) {
            return KalarRepository.newsBySourceId[sourceId].orEmpty()
        }
        if (sourceId == null) {
            return KalarRepository.newsByCategory[category].orEmpty()
        }
    }
    return allArticles.filter { article ->
        (category == NewsCategory.ALL || article.category == category) &&
            (sourceId == null || article.sourceId == sourceId)
    }
}

private fun filterPages(
    allPages: List<CategorizedFacebookPage>,
    category: OfficialPageCategory,
    queryText: String
): List<CategorizedFacebookPage> {
    val query = queryText.trim().lowercase()
    val categorySlice = if (allPages === KalarRepository.categorizedPages) {
        KalarRepository.pagesByCategory[category] ?: allPages
    } else if (category == OfficialPageCategory.ALL) {
        allPages
    } else {
        allPages.filter { it.category == category }
    }
    if (query.isEmpty()) return categorySlice
    return categorySlice.filter { page ->
        page.name.ku.lowercase().contains(query) ||
            page.name.en.lowercase().contains(query) ||
            page.subtitle.ku.lowercase().contains(query) ||
            page.subtitle.en.lowercase().contains(query)
    }
}

private data class FilterSelectionState(
    val category: ServiceCategory = ServiceCategory.ALL,
    val healthType: HealthFacilityType = HealthFacilityType.ALL,
    val newsCategory: NewsCategory = NewsCategory.ALL,
    val newsTab: NewsTabSection = NewsTabSection.FEED_TIMELINE,
    val newsSourceId: String? = null,
    val pageCategory: OfficialPageCategory = OfficialPageCategory.ALL,
    val searchQuery: String = "",
    val pagesSearchQuery: String = ""
)

private data class ModalSelectionState(
    val landmark: CityLandmark? = null,
    val service: CityService? = null,
    val healthFacility: HealthFacility? = null,
    val newsArticle: NewsArticle? = null
)

class KalarViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = PreferencesRepository(application.applicationContext)

    private val _filters = MutableStateFlow(FilterSelectionState())
    private val _modals = MutableStateFlow(ModalSelectionState())
    private val _weatherRefreshing = MutableStateFlow(false)
    private val _calendarDates = MutableStateFlow(KalarCalendarHelper.currentKalarDates())
    private val weatherMutex = Mutex()

    private val corePrefsFlow = combine(
        prefsRepo.languageFlow,
        prefsRepo.themeModeFlow,
        prefsRepo.savedIdsFlow
    ) { language, themeMode, savedIds ->
        Triple(language, themeMode, savedIds)
    }

    private val weatherCombinedFlow = combine(
        prefsRepo.cachedWeatherFlow,
        _weatherRefreshing,
        _calendarDates
    ) { cached, isRefreshing, dates ->
        Pair(cached.copy(isRefreshing = isRefreshing), dates)
    }

    val uiState: StateFlow<KalarUiState> = combine(
        corePrefsFlow,
        weatherCombinedFlow,
        _filters,
        _modals
    ) { prefsTriple, weatherPair, filters, modals ->
        KalarUiState(
            language = prefsTriple.first,
            themeMode = prefsTriple.second,
            savedIds = prefsTriple.third,
            weatherState = weatherPair.first,
            calendarDates = weatherPair.second,
            selectedCategory = filters.category,
            selectedHealthType = filters.healthType,
            selectedNewsCategory = filters.newsCategory,
            selectedNewsTab = filters.newsTab,
            selectedNewsSourceId = filters.newsSourceId,
            selectedPageCategory = filters.pageCategory,
            searchQuery = filters.searchQuery,
            pagesSearchQuery = filters.pagesSearchQuery,
            selectedLandmark = modals.landmark,
            selectedService = modals.service,
            selectedHealthFacility = modals.healthFacility,
            selectedNewsArticle = modals.newsArticle
        )
    }.flowOn(Dispatchers.Default).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = KalarUiState()
    )

    init {
        refreshWeather(force = false)
    }

    fun refreshWeather(force: Boolean = true) {
        viewModelScope.launch {
            _calendarDates.value = KalarCalendarHelper.currentKalarDates()
            if (weatherMutex.isLocked) return@launch
            weatherMutex.withLock {
                val cached = prefsRepo.cachedWeatherFlow.firstOrNull()
                val ageMs = if (cached != null && cached.updatedAtEpochMs > 0L) {
                    System.currentTimeMillis() - cached.updatedAtEpochMs
                } else {
                    Long.MAX_VALUE
                }
                if (!force && ageMs in 0L until KalarWeatherRepository.CACHE_TTL_MS) {
                    return@withLock
                }
                _weatherRefreshing.value = true
                try {
                    val freshReading = KalarWeatherRepository.fetchCurrentKalarWeather()
                    if (freshReading != null) {
                        prefsRepo.saveWeatherReading(freshReading)
                    }
                } finally {
                    _weatherRefreshing.value = false
                }
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { prefsRepo.setLanguage(language) }
    }

    fun setThemeMode(themeMode: AppThemeMode) {
        viewModelScope.launch { prefsRepo.setThemeMode(themeMode) }
    }

    fun selectCategory(category: ServiceCategory) {
        _filters.value = _filters.value.copy(category = category)
    }

    fun selectHealthType(type: HealthFacilityType) {
        _filters.value = _filters.value.copy(healthType = type)
    }

    fun selectNewsCategory(category: NewsCategory) {
        _filters.value = _filters.value.copy(newsCategory = category)
    }

    fun selectNewsTab(tab: NewsTabSection) {
        _filters.value = _filters.value.copy(newsTab = tab)
    }

    fun selectNewsSource(sourceId: String?) {
        _filters.value = _filters.value.copy(newsSourceId = sourceId)
    }

    fun selectPageCategory(category: OfficialPageCategory) {
        _filters.value = _filters.value.copy(pageCategory = category)
    }

    fun updateSearchQuery(query: String) {
        _filters.value = _filters.value.copy(searchQuery = query)
    }

    fun updatePagesSearchQuery(query: String) {
        _filters.value = _filters.value.copy(pagesSearchQuery = query)
    }

    fun openLandmark(landmark: CityLandmark) {
        _modals.value = _modals.value.copy(landmark = landmark)
    }

    fun dismissLandmark() {
        _modals.value = _modals.value.copy(landmark = null)
    }

    fun openService(service: CityService) {
        _modals.value = _modals.value.copy(service = service)
    }

    fun dismissService() {
        _modals.value = _modals.value.copy(service = null)
    }

    fun openHealthFacility(facility: HealthFacility) {
        _modals.value = _modals.value.copy(healthFacility = facility)
    }

    fun dismissHealthFacility() {
        _modals.value = _modals.value.copy(healthFacility = null)
    }

    fun openNewsArticle(article: NewsArticle) {
        _modals.value = _modals.value.copy(newsArticle = article)
    }

    fun dismissNewsArticle() {
        _modals.value = _modals.value.copy(newsArticle = null)
    }

    fun toggleSaved(id: String) {
        viewModelScope.launch { prefsRepo.toggleSavedItem(id) }
    }
}
