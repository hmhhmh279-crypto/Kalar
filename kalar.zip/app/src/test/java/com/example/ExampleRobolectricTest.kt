package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kalar", appName)
  }

  @Test
  fun `bilingual strings and repository data are populated`() {
    val kuStrings = com.example.ui.stringsFor(com.example.model.AppLanguage.KURDISH)
    val enStrings = com.example.ui.stringsFor(com.example.model.AppLanguage.ENGLISH)
    assertEquals("کەلار", kuStrings.appTitle)
    assertEquals("Kalar", enStrings.appTitle)
    assertEquals(4, com.example.data.KalarRepository.landmarks.size)
    assertEquals(6, com.example.data.KalarRepository.services.size)
    assertEquals(4, com.example.data.KalarRepository.healthFacilities.size)
    assertEquals(7, com.example.data.KalarRepository.officialLinks.size)
    assertEquals(9, com.example.data.KalarRepository.newsSources.size)
    assertEquals(9, com.example.data.KalarRepository.newsArticles.size)
    assertEquals(20, com.example.data.KalarRepository.categorizedPages.size)
    assertEquals("com.amadaapp.client", com.example.data.KalarRepository.AMADA_PACKAGE_ID)
    assertEquals(
      "https://play.google.com/store/apps/details?id=com.amadaapp.client",
      com.example.data.KalarRepository.AMADA_PLAY_STORE_URL
    )

    val allUrls = com.example.data.KalarRepository.healthFacilities.map { it.facebookUrl } +
      com.example.data.KalarRepository.officialLinks.map { it.url } +
      com.example.data.KalarRepository.newsSources.map { it.url }
    assertEquals(20, allUrls.size)
    org.junit.Assert.assertTrue(allUrls.all { com.example.data.KalarRepository.isOfficialFacebookUrl(it) })
    org.junit.Assert.assertTrue(
      com.example.data.KalarRepository.categorizedPages.all {
        com.example.data.KalarRepository.isOfficialFacebookUrl(it.url)
      }
    )
    org.junit.Assert.assertFalse(com.example.data.KalarRepository.isOfficialFacebookUrl("http://www.facebook.com/share/123"))
    org.junit.Assert.assertFalse(com.example.data.KalarRepository.isOfficialFacebookUrl("https://evil-ads.example.com/?next=facebook.com"))
    org.junit.Assert.assertTrue(allUrls.contains("https://www.facebook.com/share/1ZDCa41jZ2/"))
    org.junit.Assert.assertTrue(allUrls.contains("https://www.facebook.com/share/1SzfaPzoXB/"))
    org.junit.Assert.assertTrue(allUrls.contains("https://www.facebook.com/share/1C4RPds29y/"))

    // Every provided news source is represented in the aggregated News Feed timeline
    val sourceIdsInFeed = com.example.data.KalarRepository.newsArticles.map { it.sourceId }.toSet()
    assertEquals(
      com.example.data.KalarRepository.newsSources.map { it.id }.toSet(),
      sourceIdsInFeed
    )

    // Filtering state works cleanly for both timeline source and categorized pages
    val filteredBySource = com.example.viewmodel.KalarUiState(selectedNewsSourceId = "kalar_ktv").filteredNews
    assertEquals(1, filteredBySource.size)
    assertEquals("kalar_ktv", filteredBySource.first().sourceId)

    val healthCategorized = com.example.viewmodel.KalarUiState(
      selectedPageCategory = com.example.model.OfficialPageCategory.HEALTH_MEDICAL
    ).filteredCategorizedPages
    assertEquals(4, healthCategorized.size)

    val allTitlesKu = com.example.data.KalarRepository.healthFacilities.map { it.name.ku } +
      com.example.data.KalarRepository.officialLinks.map { it.title.ku } +
      com.example.data.KalarRepository.newsSources.map { it.name.ku }
    val allTitlesEn = com.example.data.KalarRepository.healthFacilities.map { it.name.en } +
      com.example.data.KalarRepository.officialLinks.map { it.title.en } +
      com.example.data.KalarRepository.newsSources.map { it.name.en }

    org.junit.Assert.assertTrue(allTitlesKu.contains("شاری پزیشکیی خزمەت"))
    org.junit.Assert.assertTrue(allTitlesKu.contains("بەڕێوبەرایەتی هاتووچۆ کەلار"))
    org.junit.Assert.assertTrue(allTitlesKu.contains("گەش و هەوای گەرمیان"))
    org.junit.Assert.assertTrue(allTitlesKu.contains("میدیای باجه لان"))
    org.junit.Assert.assertTrue(allTitlesKu.contains("کەلار KTV"))
    org.junit.Assert.assertTrue(allTitlesKu.contains("ئایندە میدیا"))
    org.junit.Assert.assertTrue(allTitlesEn.contains("Bajelan Media"))
    org.junit.Assert.assertFalse(allTitlesEn.any { it.contains("Page 1") || it.contains("Page 2") || it.contains("Page 3") })

    // Every single one of the 20 pages has a distinct brand profile logo monogram and color pair
    val allBrands = com.example.data.KalarRepository.pageBrands
    assertEquals(20, allBrands.size)
    assertEquals(20, allBrands.values.map { it.monogram }.toSet().size)
    assertEquals(20, allBrands.values.map { it.primaryColorHex to it.secondaryColorHex }.toSet().size)
    org.junit.Assert.assertTrue(
      com.example.data.KalarRepository.newsArticles.all {
        it.brand == com.example.data.KalarRepository.brandForId(it.sourceId)
      }
    )

    // O(1) repository indices match the full datasets cleanly
    assertEquals(20, com.example.data.KalarRepository.pageCountsByCategory[com.example.model.OfficialPageCategory.ALL])
    assertEquals(4, com.example.data.KalarRepository.pageCountsByCategory[com.example.model.OfficialPageCategory.HEALTH_MEDICAL])
    assertEquals(3, com.example.data.KalarRepository.pageCountsByCategory[com.example.model.OfficialPageCategory.DIRECTORATES_WEATHER])
    assertEquals(4, com.example.data.KalarRepository.pageCountsByCategory[com.example.model.OfficialPageCategory.COMMUNITY_OFFICIAL])
    assertEquals(9, com.example.data.KalarRepository.pageCountsByCategory[com.example.model.OfficialPageCategory.LOCAL_NEWS])
    assertEquals(
      1,
      com.example.data.KalarRepository.newsBySourceId["kalar_news_1ewa"]?.size
    )
    assertEquals(
      "میدیای باجه لان",
      com.example.data.KalarRepository.newsBySourceId["kalar_news_1ewa"]?.first()?.sourceName?.ku
    )
  }

  @Test
  fun `kurdish and gregorian calendar dates convert accurately`() {
    val newroz2026 = com.example.data.KalarCalendarHelper.fromGregorian(2026, 3, 21)
    assertEquals("1 خاکەلێوە 2726", newroz2026.formatKurdishDate(com.example.model.AppLanguage.KURDISH))
    assertEquals("1 Xakelêwe 2726", newroz2026.formatKurdishDate(com.example.model.AppLanguage.ENGLISH))
    assertEquals("21 ئازار 2026", newroz2026.formatGregorianDate(com.example.model.AppLanguage.KURDISH))
    assertEquals("21 Mar 2026", newroz2026.formatGregorianDate(com.example.model.AppLanguage.ENGLISH))

    val beforeNewroz2026 = com.example.data.KalarCalendarHelper.fromGregorian(2026, 3, 20)
    assertEquals("29 ڕەشەمێ 2725", beforeNewroz2026.formatKurdishDate(com.example.model.AppLanguage.KURDISH))

    val nov15_2026 = com.example.data.KalarCalendarHelper.fromGregorian(2026, 11, 15)
    assertEquals("24 گەڵاڕێزان 2726", nov15_2026.formatKurdishDate(com.example.model.AppLanguage.KURDISH))
    assertEquals("24 Gelařêzan 2726", nov15_2026.formatKurdishDate(com.example.model.AppLanguage.ENGLISH))
    assertEquals("15 تشرینی دووەم 2026", nov15_2026.formatGregorianDate(com.example.model.AppLanguage.KURDISH))
    assertEquals("15 Nov 2026", nov15_2026.formatGregorianDate(com.example.model.AppLanguage.ENGLISH))
  }

  @Test
  fun `kalar live weather json parses exact temperature and rejects malformed payload`() {
    val samplePayload = """{"current":{"temperature_2m":21.4,"weather_code":1,"is_day":1}}"""
    val parsed = com.example.data.KalarWeatherRepository.parseOpenMeteoResponse(samplePayload, 1_700_000_000_000L)
    org.junit.Assert.assertNotNull(parsed)
    assertEquals(21.4, parsed!!.temperatureCelsius, 0.001)
    assertEquals(com.example.model.KalarWeatherCondition.PARTLY_CLOUDY, parsed.condition)
    assertEquals(true, parsed.isDay)

    org.junit.Assert.assertNull(com.example.data.KalarWeatherRepository.parseOpenMeteoResponse("{}", 1L))
  }
}

